import utilities

from A4 import Base_Cipher

def test_valid_configuration(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.valid_configuration Testing")
    print()
    grade = 0

    cases = [('A','Z',4),('a','M',3),('H','I',2),('r','q',5),(124,'f',7),('AB','S',3),
             ('Q','Q',2),('j','?',3),('.','2',9),('A','Z',0),('a','p','3'),['a','p','3']]
    answers = [True,True,True,False,False,False,False,False,False,False,False,False]
    for i in range(len(cases)):
        result = Base_Cipher.valid_configuration(cases[i])
        print('valid_configuration({}) = {}'.format(cases[i],result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
    
    print('End of Base_Cipher.valid_configuration Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_get_alphabet(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.get_alphabet Testing")
    print()
    grade = 0

    cases = [('A','Z',4),('a','M',3),('s','5',6),('H','I',2),('r','q',5),
             ('G',150,2),['c','h',3],
             ('e','e',2),('#','K',1)]
    answers = ['ABCDEFGHIJKLMNOPQRSTUVWXYZ',
               'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM',
               'stuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012345',
               'HI','','','','','']
    for i in range(len(cases)):
        result = Base_Cipher.get_alphabet(cases[i])
        print('get_alphabet({}) = {}'.format(cases[i],result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.get_alphabet Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_valid_key(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.valid_key Testing")
    print()
    grade = 0

    cases = [(('A','Z',5),'OK'),(('a','z',4),'pi'),(('q','R',3),'Hut'),
             (('u','7',2),'v2x'),(('b','o',6),140),(('J','T',0),'SOP'),
             [('m','E',3),'nop'],(('A','S',6),'SMART')]
    answers = [True,True,True,False,False,False,False,False,False,False]
    for i in range(len(cases)):
        c = cases[i]
        result = Base_Cipher.valid_key(c)
        print('valid_key({}) = {}'.format(c,result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.valid_key Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_set_get_key(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher set_key and get_key Testing")
    print()
    grade = 0

    cipher = Base_Cipher()
    
    cases = [(('A','Z',5),'OK'),(('a','z',4),'pi'),(('q','R',3),'Hut'),
             (('u','7',2),'v2x'),(('b','o',6),140),(('J','T',0),'SOP'),
             [('m','E',3),'nop'],(('A','S',6),'SMART')]
    answers1 = [True,True,True,False,False,False,False,False]
    answers2 = [(('A','Z',5),'OK'),(('a','z',4),'pi'),(('q','R',3),'Hut'),
                (('A','Z',5),'CRYPT'),(('A','Z',5),'CRYPT'),(('A','Z',5),'CRYPT'),
                (('A','Z',5),'CRYPT'),(('A','Z',5),'CRYPT')]
    for i in range(len(cases)):
        c = cases[i]
        result1 = cipher.set_key(c)
        result2 = cipher.get_key()
        print('set_key({}) = {}'.format(c,result1))
        if result1 == answers1[i]:
            grade += max_grade/(2*len(cases))
        print('get_key({}) = {}'.format(c,result2))
        if result2 == answers2[i]:
            grade += max_grade/(2*len(cases))
    print()
        
    print('End of Base_Cipher set_key and get_key Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_get_base(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.get_base Testing")
    print()
    grade = 0
    cipher = Base_Cipher()
    
    cases = [(('A','Z',5),'OK'),(('a','M',4),'pi'),(('s','5',3),'Hut'),
             (('H','I',5),'HI')]
    answers = [26,39,40,2]
    for i in range(len(cases)):
        c = cases[i]
        cipher.set_key(c)
        result = cipher.get_base()
        print('key = {}, get_base() = {}'.format(cipher.get_key(),result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.get_base Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_get_mod(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.get_mod Testing")
    print()
    grade = 0
    cipher = Base_Cipher()
    
    cases = [(('A','Z',5),'OK'),(('a','z',4),'ok'),(('q','R',3),'MuM'),
             (('u','7',2),'w2'),(('b','o',1),'g'),(('p','U',6),'SUN')]
    answers = ['BAAAAA','baaaa','rqqq','vuu','cb','qpppppp']
    for i in range(len(cases)):
        c = cases[i]
        cipher.set_key(c)
        result = cipher.get_mod()
        print('key = {}, get_mod() = {}'.format(c,result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.get_mod Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_str(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.__str__ Testing")
    print()
    grade = 0
    
    cases = [None,(('A','Z',5),'OK'),(('a','M',4),'pi'),(('s','5',3),'Hut'),
             (('H','I',5),'HI')]
    answers = ['y = x + CRYPT mod BAAAAA','y = x + OK mod BAAAAA',
               'y = x + pi mod baaaa',
               'y = x + Hut mod tsss','y = x + HI mod IHHHHH']
    for i in range(len(cases)):
        cipher = Base_Cipher(cases[i])
        result = cipher.__str__()
        print(cipher)
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.__str__ Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_preprocess(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.preprocess Testing")
    print()
    grade = 0
    cipher = Base_Cipher()
    print(cipher)
    cases = ['SMART','DUCK','OK','SMART QUEST','BUY 2 ORANGES', 'HEALTHY-LUNGS',
             'Mathematical Ciphers','Vulnerability-Assessment']
    answers1 = ['SMART','DUCKZ','OKZZZ','SMARTQUEST', 'BUYORANGES','HEALTHYLUNGSZZZ',
                'MthemtilCiphers5','VulnerilityAssessment555']
    answers2 = [[],[],[],[[' ',5]],[[' ', 3], ['2', 4], [' ', 5]],
                [['-', 7]],[['a', 1], ['a', 6], ['c', 9], ['a', 10], [' ', 12]],
                [['a', 6], ['b', 7], ['-', 13]]]
    for i in range(len(cases)):
        if i == 6:
            cipher.set_key((('d','5',4),'PSUT'))
            print()
            print(cipher)
        result,positions = cipher.preprocess(cases[i])
        print('preprocess({}) = {},{}'.format(cases[i],result,positions))
        if result == answers1[i]:
            grade += max_grade/(2*len(cases))
        if positions == answers2[i]:
            grade += max_grade/(2*len(cases))
    print()
        
    print('End of Base_Cipher.preprocess Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_encode(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.encode Testing")
    print()
    grade = 0
    cipher = Base_Cipher((('A','Z',5),'AGING'))
    print(cipher)
    cases = ['A','BA','FINDA','GOODD','OCTOR','BAAAAA','Best','Mexico City',15]
    answers = [0,26,2434354,2997465,6446041,11881376,1,314,-1]
    for i in range(len(cases)):
        result = cipher.encode(cases[i])
        print('encode({}) = {}'.format(cases[i],result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.encode Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_decode(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.decode Testing")
    print()
    grade = 0
    cipher = Base_Cipher((('A','Z',5),'AGING'))
    print(cipher)
    cases = [0,26,2434354,2997465,6446041,11881376,1,314,-1]
    answers = ['A','BA','FINDA','GOODD','OCTOR','BAAAAA','B','MC','']
    for i in range(len(cases)):
        result = cipher.decode(cases[i])
        print('decode({}) = {}'.format(cases[i],result))
        if result == answers[i]:
            grade += max_grade/len(cases)
    print()
        
    print('End of Base_Cipher.decode Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_encrypt(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.encrypt Testing")
    print()
    grade = 0
    cipher = Base_Cipher((('A','Z',5),'AGING'))
    print(cipher)
    cases = ['FINDAGOODDOCTOR','PROPERTY','Intro To Network Prog & Applications']
    answers = ['FOVQGGUWQJOJCBX','PXXCKSAHNF',
               'Intro Zo Wetwork Crog & Gpplications']
    for i in range(len(cases)):
        plaintext = cases[i]
        print('plaintext =  {}'.format(plaintext))
        ciphertext = cipher.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext))
        if ciphertext == answers[i]:
            grade += max_grade/(2*len(cases))
    print()

    cipher = Base_Cipher((('a','M',3),'sun'))
    print(cipher)
    cases = ['Find a Good Doctor','property','Intro To Network Prog & Applications']
    answers = ['kCAv v gGIq iIpLIE','HLBHyEMgm',
               'nHGJI TB NxaJGLx PJIt & fJCDCptavGHF']
    for i in range(len(cases)):
        plaintext = cases[i]
        print('plaintext =  {}'.format(plaintext))
        ciphertext = cipher.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext))
        if ciphertext == answers[i]:
            grade += max_grade/(2*len(cases))
    print()
            
    print('End of Base_Cipher.encrypt Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def test_decrypt(max_grade):
    print('{}'.format('-'*40))
    print("Start of Base_Cipher.decrypt Testing")
    print()
    grade = 0
    cipher = Base_Cipher((('A','Z',5),'AGING'))
    print(cipher)
    answers = ['FINDAGOODDOCTOR','PROPERTY','Intro To Network Prog & Applications']
    cases = ['FOVQGGUWQJOJCBX','PXXCKSAHNF',
               'Intro Zo Wetwork Crog & Gpplications']
    for i in range(len(cases)):
        ciphertext = cases[i]
        print('ciphertext =  {}'.format(ciphertext))
        plaintext = cipher.decrypt(ciphertext)
        print('plaintext  = {}'.format(plaintext))
        if plaintext == answers[i]:
            grade += max_grade/(2*len(cases))
    print()

    cipher = Base_Cipher((('a','M',3),'sun'))
    print(cipher)
    answers = ['Find a Good Doctor','property','Intro To Network Prog & Applications']
    cases = ['kCAv v gGIq iIpLIE','HLBHyEMgm',
               'nHGJI TB NxaJGLx PJIt & fJCDCptavGHF']
    for i in range(len(cases)):
        ciphertext = cases[i]
        print('ciphertext = {}'.format(ciphertext))
        plaintext = cipher.decrypt(ciphertext)
        print('plaintext  = {}'.format(plaintext))
        if plaintext == answers[i]:
            grade += max_grade/(2*len(cases))
    print()
            
    print('End of Base_Cipher.decrypt Testing')
    print('{}'.format('-'*40))
    print()
    return grade

def grader():    
    grades = [0 for _ in range(12)]
    scores = [10,9,9,4,4,6,4,10,10,10,12,12]
    grades[0] = test_valid_configuration(scores[0])
    grades[1] = test_get_alphabet(scores[1])
    grades[2] = test_valid_key(scores[2])
    grades[3] = test_set_get_key(scores[3])
    grades[4] = test_get_base(scores[4])
    grades[5] = test_get_mod(scores[5])
    grades[6] = test_str(scores[6])
    grades[7] = test_preprocess(scores[7])
    grades[8] = test_encode(scores[8])
    grades[9] = test_decode(scores[9])
    grades[10] = test_encrypt(scores[10])
    grades[11] = test_decrypt(scores[11])
    total = sum(grades)

    print('{}'.format('-'*40))
    print("Start of Grader")
    print()   
    print('valid_configuration  = {:.2f}/{}'.format(grades[0],scores[0]))
    print('get_alphabet         = {:.2f}/{}'.format(grades[1],scores[1]))
    print('valid_key            = {:.2f}/{}'.format(grades[2],scores[2]))
    print('set_key & get_key    = {:.2f}/{}'.format(grades[3],scores[3]))
    print('get_base             = {:.2f}/{}'.format(grades[4],scores[4]))
    print('get_mode             = {:.2f}/{}'.format(grades[5],scores[5]))
    print('__str__              = {:.2f}/{}'.format(grades[6],scores[6]))
    print('preprocess           = {:.2f}/{}'.format(grades[7],scores[7]))
    print('encode               = {:.2f}/{}'.format(grades[8],scores[8]))
    print('decode               = {:.2f}/{}'.format(grades[9],scores[9]))
    print('encrypt              = {:.2f}/{}'.format(grades[10],scores[10]))
    print('decrypt              = {:.2f}/{}'.format(grades[11],scores[11]))

    print()
    print('Total = {:.2f}/100'.format(total))
    print()
    
    print('End of Grader Testing')
    print('{}'.format('-'*40))
    return 

# test_valid_configuration(10)
# test_get_alphabet(9)
# test_valid_key(9)
# test_set_get_key(4)
# test_get_base(4)
# test_get_mod(6)
# test_str(4)
# test_preprocess(10)
# test_encode(10)
# test_decode(10)
# test_encrypt(12)
# test_decrypt(12)
grader()