#------------------------
# Cryptography (Winter 2023)
# Assignment 4: Math Ciphers
#------------------------

#------------------------
# Student Name: yazan tariq abugazah
# Student ID: 20200906
#------------------------

import utilities

class Base_Cipher:
    ALPHABET = utilities.get_chars('lower') + utilities.get_chars('uppernum')
    DEFAULT_KEY = (('A','Z',5),'CRYPT')
    
    def __init__(self,key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Base_Cipher Constructor
        Parameters:   key (tuple): 
                        (config (tuple), keyword (str)    
        Description:  Constrct a cipher_base object
                      Has one private property: __key
                      If given key is valid --> set key to given value
                      otherwise, set key to DEFAULT_KEY
        ----------------------  ------------------------------
        """
        if self.valid_key(key):
            self.__key = key
        else:
            self.__key = self.DEFAULT_KEY

    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Creates a string representation of Base_Cipher objects
                      Format: y = x + <keyword> mod <m>
        ----------------------------------------------------
        """
        config, keyword = self.__key
        m = self.get_mod()
        output = f"y = x + {keyword} mod {m}"
        return output

    @staticmethod
    def valid_configuration(config):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   input(?)
        Return:       True/False
        Description:  Check if given configuration is valid
                      A valid configuration is a tuple of 3 items
                      First item is a single character in ALPHABET
                      Second item is a single character in ALPHABET
                          which is after First
                      Third item is a positive integer
        ----------------------------------------------------
        """
        if not type(config) == tuple or len(config) != 3:
            return False

        first_item, second_item, third_item = config

        if (not type(first_item) == str or len(first_item) != 1 or
                not first_item in Base_Cipher.ALPHABET):
            return False

        if (not type(second_item) == str or len(second_item) != 1 or
                not second_item in Base_Cipher.ALPHABET or
                Base_Cipher.ALPHABET.index(first_item) >= Base_Cipher.ALPHABET.index(second_item)):
            return False

        if not type(third_item) == int or third_item <= 0:
            return False

        return True

    
    @staticmethod
    def get_alphabet(config):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   input(?)
        Return:       alphabet (str)
        Description:  Return corresponding alphabet for a given configuration
                      The alphabet is a subset of ALPHABET
                      If invalid config return empty string
        ----------------------------------------------------
        """
        if not Base_Cipher.valid_configuration(config):
            return ""

        first_item, second_item, _ = config
        alphabet = Base_Cipher.ALPHABET[
                   Base_Cipher.ALPHABET.index(first_item):Base_Cipher.ALPHABET.index(second_item) + 1
                   ]
        return "".join(alphabet)

    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key(?)
        Return:       True/False
        Description:  Check if given arg is a valid Base_Cipher key
                      A valid key is a tuple consisting of 2 elements
                      (config,keyword)
                      The config should be a valid configuration
                      The keyword should be:
                          1- A string
                          2- All characters defined in the alphabet
                          3- Smaller than the block size
        ----------------------------------------------------
        """
        if not type(key) == tuple or len(key) != 2:
            return False

        config, keyword = key

        if not Base_Cipher.valid_configuration(config):
            return False

        if (not type(keyword) == str or
                any(char not in Base_Cipher.get_alphabet(config) for char in keyword) or
                len(keyword) > config[2]):
            return False

        return True

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (tuple)
        Description:  Returns a copy of key
        ----------------------------------------------------
        """
        return self.__key
    
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key(?)
        Return:       True/False
        Description:  set key to given argument
                      If valid --> set key and return True
                      otherwise --> set key to DEFAULT_KEY and return False
        ----------------------------------------------------
        """
        if self.valid_key(key):
            self.__key = key
            return True
        else:
            self.__key = self.DEFAULT_KEY
            return False

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (int)
        Description:  Computes and returns the mathematical base
                      For example: lowercase alphabet --> 26
        ----------------------------------------------------
        """
        config, keyword = self.__key
        return len(self.get_alphabet(config))
    
    def get_mod(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mod (str)
        Description:  Computes and returns the mod for the cipher
                      For example: lowercase with block size = 5 --> baaaaa
        ----------------------------------------------------
        """
        config, keyword = self.__key
        alphabet = self.get_alphabet(config)
        block_size = config[2]
        first_char = alphabet[1]
        second_char = alphabet[0]

        mod = first_char + (second_char * block_size)
        return mod

    def preprocess(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext(str)
        Return:       modified_text (str)
                      positions (2D list)
        Description:  Formats the given plaintext by:
                        1- Remove unused characters
                        2- Pad, if necessary, with last character in alphabet
        ----------------------------------------------------
        """
        config, keyword = self.__key
        alphabet = self.get_alphabet(config)
        unused = ''
        for char in plaintext:
            if char not in alphabet:
                unused += char

        base = ' '+'\n'+'\t' + utilities.get_chars('special')+unused

        pos = utilities.get_positions(plaintext, base)
        new_text = utilities.clean_text(plaintext, base)

        block_size = config[2]
        padding_char = alphabet[-1]
        remaining = len(new_text) % block_size
        if remaining > 0:
            padding_length = block_size - remaining
            new_text += padding_char * padding_length

        return new_text, pos

    def encode(self,block):
        """
        ----------------------------------------------------
        Parameters:   block(str)
        Return:       code (int)
        Description:  Converts a given text into a code (integer) in
                      the given base
                      For example, in base = 26
                      A --> 0
                      BA --> 26
        ----------------------------------------------------
        """
        config, keyword = self.__key
        alphabet = self.get_alphabet(config)
        base = self.get_base()
        code = 0
        if type(block) != str:
            return -1
        for char in block:
            if char in alphabet:
                code = code * base + alphabet.index(char)

        return code
    
    def decode(self,number):
        """
        ----------------------------------------------------
        Parameters:   code(int)
        Return:       text (str)
        Description:  Converts a given code (integer) to text in the given base
                      For example, in base = 26
                      0 --> A
                      26 --> BA
        ----------------------------------------------------
        """
        config, keyword = self.__key
        alphabet = self.get_alphabet(config)
        base = self.get_base()

        text = ""
        if number == 0:
            return alphabet[0]

        while number > 0:
            remainder = number % base
            text = alphabet[remainder] + text
            number //= base

        return text

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext(str)
        Return:       ciphertext (str)
        Description:  Encrypts given plaintext using Base_Cipher
        ----------------------------------------------------
        """
        config, keyword = self.__key
        alphabet = self.get_alphabet(config)
        m = self.encode(self.get_mod())
        unused = ''
        for char in plaintext:
            if char not in alphabet:
                unused += char

        base = ' ' + '\n' + '\t' + utilities.get_chars('special') + unused

        pos = utilities.get_positions(plaintext, base)
        plaintext = utilities.clean_text(plaintext, base)

        blocks = utilities.text_to_blocks(plaintext, config[2])

        ciphertext = ""

        keyword_code = self.encode(keyword)

        for block in blocks:
            if len(block) < config[2]:
                padding_length = config[2] - len(block)
                block += alphabet[-1] * padding_length

            encoded_block = self.encode(block)
            encrypted_code = (encoded_block + keyword_code) % m
            encrypted_block = self.decode(encrypted_code)
            ciphertext += encrypted_block

        ciphertext = utilities.insert_positions(ciphertext, pos)

        return ciphertext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext(str)
        Return:       plaintext(str)
        Description:  Decrypts given ciphertext using Base_Cipher
        ----------------------------------------------------
        """
        config, keyword = self.__key
        alphabet = self.get_alphabet(config)
        m = self.encode(self.get_mod())

        unused = ''
        for char in ciphertext:
            if char not in alphabet:
                unused += char

        base = ' ' + '\n' + '\t' + utilities.get_chars('special') + unused

        pos = utilities.get_positions(ciphertext, base)
        ciphertext = utilities.clean_text(ciphertext, base)

        blocks = utilities.text_to_blocks(ciphertext, config[2])

        plaintext = ""

        keyword_code = self.encode(keyword)

        for block in blocks:
            encoded_block = self.encode(block)
            decrypted_code = (encoded_block - keyword_code) % m
            decrypted_block = self.decode(decrypted_code)
            plaintext += decrypted_block

        plaintext = utilities.insert_positions(plaintext, pos)

        while plaintext[-1] == alphabet[-1]:
            plaintext = plaintext[:-1]

        return plaintext
