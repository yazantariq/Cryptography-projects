import utilities
import string
NAME = 'Yazan_Abugazah'     #<------- edit this to be your name, should match your file name

class exam_info:
    
    @staticmethod
    def get_first_name():
        first,_ = NAME.split('_')
        return first  
    
    @staticmethod
    def get_last_name():
        _,last = NAME.split('_')
        return last
    
    @staticmethod    
    def get_ID():
        return '20200906'            #<------- edit this with your student ID
    
    @staticmethod
    def get_certification():
        return 'I certify that I completed this exam according to academic integrity guidelines. The submitted work is my original work. I attest that I did not use any external help, neither in person nor virtually. I understand that failing to abide by the academic integrity guidelines may lead to my failure in the course, in addition to other disciplinary measures outlined by the university'   #<------- edit this string with your honor pledge

    @staticmethod
    def get_comments():
        output = 'Finally'
        return output
    
    @staticmethod
    def get_task1_solution():
        key = (13, 23, 34, 16, 59) #<---------- hard-code your Task 1 key here
        filename = 'plaintext1_' + NAME + '.txt'
        plaintext = utilities.file_to_text(filename)
        return key,plaintext
    
    @staticmethod
    def get_task2_solution():
        key = 'vv'               #<---------- hard-code your Task 2 key here
        filename = 'plaintext2_' + NAME + '.txt'
        plaintext = utilities.file_to_text(filename)
        return key,plaintext
    
    @staticmethod
    def get_task3_solution():
        sub = 'rcjpfatyzhuoqminvlkwbdxges?-:, .;'  #<---------- hard-code your Task 3 sub here
        key = sub
        filename = 'plaintext3_' + NAME + '.txt'
        plaintext = utilities.file_to_text(filename)
        return key,plaintext        

#-------------------- Task 1: Math Cipher ----------------------
class Mathx:
    """
    ----------------------------------------------------
    Cipher name: Mathx
    Key:         (a,b,c,start,end)
    Type:        Substitution Cipher
    Description: y = (a + b - c)x + bc - a mod m
                 base = BASE[start:end]
                 m = len(base)
                 Applies only to characters defined in the base
    ----------------------------------------------------
    """
    BASE = utilities.get_chars('BA')
    DEFAULT_KEY = (11,8,14,26,52)

    def __init__(self,key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key: tuple(int,int,int,int,int): (a,b,c,start,end)
        Description:  Mathx constructor
                      sets _key
        ---------------------------------------------------
        """
        self._key = key

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int,int,int,int,int)
        Description:  Returns a copy of the Mathx key
        ---------------------------------------------------
        """
        return self._key

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the Mathx base
                        which is a subset of BASE
                        to find the base start for end-start
        ---------------------------------------------------
        """
        a, b, c, start, end = self._key
        base = self.BASE[start:end]
        return base

    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Mathx key
                      A valid key is a tuple of 5 integers (a,b,c,start,end)
                      You should find a way to validate a,b and c
                      start < end, and both are positive valid indexes for BASE
                      The base should contain at least two characters
        ---------------------------------------------------
        """
        if type(key) != tuple:
            return False
        if len(key) != 5:
            return False
        if type(key[0]) != int or type(key[1]) != int or type(key[2]) != int or type(key[3]) != int or type(key[4]) != int:
            return False
        if key[3] < 0 or key[4] < 0:
            return False
        if key[4] - key[3] < 2:
            return False
        x = key[0] + key[1] - key[2]
        d = key[4] - key[3]
        if utilities.MOD.gcd(x, d) != 1:
            return False
        if key[4] > len(Mathx.BASE):
            return False
        return True

    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple): tuple(int,int,int,int,int)
        Return:       success: True/False
        Description:  Sets Mathx key to given key
                      If given argument is a valid key, set and return True
                      If necessary set a, b and c to residue values
                      if invalid key --> set to default key and return False
        ---------------------------------------------------
        """
        d = key[4] - key[3]
        if self.valid_key(key):
            a, b, c, start, end = key
            self._key = (a % d, b % d, c % d, start, end)
            return True
        else:
            self._key = self.DEFAULT_KEY
            return False

    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Mathx object. Used for testing
                      output format:
                      Mathx: y = (<a>+<b>-<c>)*x + <b>*<c> - <a> mod <m>
        ---------------------------------------------------
        """
        a, b, c, start, end = self._key
        m = len(self.get_base())
        output = f"Mathx: y = ({a}+{b}-{c})*x + {b}*{c} - {a} mod {m}"
        return output

    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Mathx cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert type(plaintext) == str, 'invalid ciphertext'
        a, b, c, start, end = self._key
        base = self.get_base()
        m = len(base)
        ciphertext = ""
        for char in plaintext:
            if char in base:
                x = base.index(char)
                y = (a + b - c) * x + b * c - a
                y %= m
                ciphertext += base[y]
            else:
                ciphertext += char

        return ciphertext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Mathx cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid ciphertext'
        a, b, c, start, end = self._key
        base = self.get_base()
        m = len(base)
        plaintext = ""
        n = 0
        eq = a+b-c
        if utilities.MOD.has_mul_inv(eq,m):
            if eq < 0:
                eq = eq % m
                n = utilities.MOD.get_mul_inv(eq, m)
            else:
                n = utilities.MOD.get_mul_inv(eq, m)
        for char in ciphertext:
            if char in base:
                y = base.index(char)
                x = (y+a - (b*c)) * n
                x %= m
                plaintext += base[x]
            else:
                plaintext += char

        return plaintext
    
    def classify(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       classification (str)
        Description:  Inspects current Mathx cipher and return its type
                      Defined types:
                          No_Encipherment, Shift, Decimation, Affine
        ---------------------------------------------------
        """
        base = self.get_base()
        m = len(base)
        a, b, c, start, end = self._key
        eq1 = (a + b - c) % m
        eq2 = (b*c - a) % m

        if eq1 != 0 and eq2 == 0 and eq1 !=1:
            return 'Decimation'
        elif eq1 != 0 and eq2 != 0 and eq1 !=1:
            return 'Affine'
        elif eq1 == 1 and eq2 == 0:
            return 'No_Encipherment'
        elif eq1 == 1 and eq2 !=0:
            return 'Shift'

    @staticmethod
    def analyze_keydomain(base):
        """
        ----------------------------------------------------
        Static method
        Parameters:   base (str)
        Return:       counters (list of 5 integers)
        Description:  Generates all possible Mathx keys for a given base
                      Then checks how many keys are: no_encipherment, shift,
                          decimatnion, affine and invalid
                      This is stored in a list of five counters [int,int,int,int,int]
                      Assume base is always a valid subset of BASE
        ---------------------------------------------------
        """
        counters = [0, 0, 0, 0, 0]
        start = base[0]
        end = base[-1]
        for a in range(base[-1] - base[0]):
            for b in range(base[-1] - base[0]):
                for c in range(base[-1] - base[0]):
                    key = (a, b, c, start, end)

                    if Mathx.valid_key(key) != True:
                        counters[4] +=1
                    else:

                        mathx = Mathx(key)
                        classification = mathx.classify()

                        if classification == 'No_Encipherment':
                            counters[0] += 1
                        elif classification == 'Shift':
                            counters[1] += 1
                        elif classification == 'Decimation':
                            counters[2] += 1
                        elif classification == 'Affine':
                            counters[3] += 1
                        else:
                            counters[4] += 1

        return counters

    @staticmethod
    def cryptanalyze(ciphertext):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (str)
        Return:       key (tuple)
                      plaintext (str)
        Description:  Cryptanalyzes a given Mathx ciphertext
        ---------------------------------------------------
        """
        dictionary = utilities.dictionary_to_list('engmix.txt')
        b = 23
        end = 59

        for start in range(0,57):
            len = end - start
            for a in range(len):
                for c in range(len):
                    key = (a, b, c, start, end)
                    mathx = Mathx(key)
                    plaintext = mathx.decrypt(ciphertext)
                    if utilities.is_plaintext(plaintext, dictionary):
                        key = mathx.get_key()
                        return key,plaintext
        return '',''
#-------------------- Task 2: Vigenerex Cipher -------------------------
class Vigenerex:
    """
    ----------------------------------------------------
    Cipher name: Vigenerex Cipher
    Key:         (str): 2 lower case alphabetical characters
    Type:        Polyalphabetic Substitution + Transposition Cipher
    Description: Encrypt using Swapt then Vigenere
                 For swapt: apply on all characters except white spaces
                 For Vigenere: apply only on alphabetical characters
                     Use running key method
                     Preserves the case of characters
    ----------------------------------------------------
    """
    
    DEFAULT_KEY = 'km'
    
    def __init__(self,key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default value: 'km'
        Description:  Vigenerex constructor
                      sets _key
                      if invalid key, set to default key
        ---------------------------------------------------
        """
        if self.valid_key(key):
            self.__key = key

        else:
            self.__key = self.DEFAULT_KEY
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Vigenerex key
        ---------------------------------------------------
        """
        return self.__key
       
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (?)
        Return:       success: True/False
        Description:  Sets Vigenerex cipher key to given key
                      If given argument is a valid key, set and return True
                      if invalid key --> set to default key and return False
        ---------------------------------------------------
        """
        if self.valid_key(key):
            self.__key = key
            return True
        else:
            self.__key = self.DEFAULT_KEY
            return False

    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Vigenerex object. Used for testing
                      output format:
                      Vigenerex Cipher: key = <key>
        ---------------------------------------------------
        """
        output = f"Vigenerex Cipher: key = {self.__key}"
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Vigenerex key
                      A valid key is a string composing of only two
                      lower case alpha characters
        ---------------------------------------------------
        """
        if type(key) == str and len(key) == 2 and key.isalpha() and key.islower():
            return True
        else:
            return False

    def encrypt_swapt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext(str)
        Return:       ciphertext(str)
        Description:  Encrypts given plaintext only using swapt
                      See PDF for instructions
        ---------------------------------------------------
        """
        ciphertext = ""
        base = ' ' + '\n'
        pos = utilities.get_positions(plaintext, base)
        plaintext = utilities.clean_text(plaintext, base)

        # Round 1:
        pairs = utilities.text_to_blocks(plaintext, 2)
        swapped_pairs = [pair[::-1] for pair in pairs]
        ciphertext += "".join(swapped_pairs)

        # Round 2:
        blocks_4 = utilities.text_to_blocks(ciphertext, 4)
        swapped_blocks_4 = [block[2:] + block[:2] if len(block) == 4 else block for block in blocks_4]
        ciphertext = "".join(swapped_blocks_4)

        # Round 3:
        blocks_6 = utilities.text_to_blocks(ciphertext, 6)
        swapped_blocks_6 = [block[3:] + block[:3] if len(block) == 6 else block for block in blocks_6]
        ciphertext = "".join(swapped_blocks_6)

        # Round 4:
        blocks_8 = utilities.text_to_blocks(ciphertext, 8)
        swapped_blocks_8 = [block[4:] + block[:4] if len(block) == 8 else block for block in blocks_8]
        ciphertext = "".join(swapped_blocks_8)

        ciphertext = utilities.insert_positions(ciphertext,pos)
        return ciphertext

    def decrypt_swapt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext(str)
        Return:       plaintext(str)
        Description:  Decrypts given ciphertext only using swapt
        ---------------------------------------------------
        """
        plaintext = ""
        base = ' ' + '\n'
        pos = utilities.get_positions(ciphertext, base)
        ciphertext = utilities.clean_text(ciphertext, base)

        # Round 4:
        blocks_8 = utilities.text_to_blocks(ciphertext, 8)
        swapped_blocks_8 = [block[-4:] + block[:4] if len(block) == 8 else block for block in blocks_8]
        plaintext = "".join(swapped_blocks_8)

        # Round 3:
        blocks_6 = utilities.text_to_blocks(plaintext, 6)
        swapped_blocks_6 = [block[-3:] + block[:3] if len(block) == 6 else block for block in blocks_6]
        plaintext = "".join(swapped_blocks_6)

        # Round 2:
        blocks_4 = utilities.text_to_blocks(plaintext, 4)
        swapped_blocks_4 = [block[-2:] + block[:2] if len(block) == 4 else block for block in blocks_4]
        plaintext = "".join(swapped_blocks_4)

        # Round 1:
        pairs = utilities.text_to_blocks(plaintext, 2)
        swapped_pairs = [pair[::-1] for pair in pairs]
        plaintext = "".join(swapped_pairs)

        plaintext = utilities.insert_positions(plaintext, pos)
        return plaintext

    def encrypt_vigenere(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Vigenere cipher (running key of 2 chars)
                      Encrypts only alphabetical characters
                      Preserves character case
        ---------------------------------------------------
        """
        ciphertext = ''
        alpha_length = 26
        toUpper = 32
        key = self.get_key()

        key_index = 0
        for char in plaintext:

            if char.isalpha():

                if key_index >= len(key):
                    key_index = 0

                if ord(char) >= 97:
                    plainchar = ord(char) - 97
                    keychar = ord(key[key_index]) - 97
                    cipherchar = (plainchar + keychar) % alpha_length
                    cipherchar = cipherchar + 97

                    ciphertext += chr(cipherchar)

                else:
                    char = char.lower()
                    plainchar = ord(char) - 97
                    keychar = ord(key[key_index]) - 97
                    cipherchar = (plainchar + keychar) % alpha_length
                    cipherchar = cipherchar + 97
                    cipherchar -= toUpper

                    ciphertext += chr(cipherchar)

                key_index += 1

            else:
                ciphertext += char

        return ciphertext

    def decrypt_vigenere(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Vigenere Cipher (running key of 2 chars)
                      Decrypts only alphabetical characters
                      Preserves character case
        ---------------------------------------------------
        """
        plaintext = ''
        alpha_length = 26
        toUpper = 32
        key = self.get_key()

        key_index = 0
        for char in ciphertext:
            if char.isalpha():
                if key_index >= len(key):
                    key_index = 0

                if char.islower():
                    cipherchar = ord(char) - 97
                    keychar = ord(key[key_index].lower()) - 97
                    plainchar = (cipherchar - keychar) % alpha_length
                    plainchar = plainchar + 97
                    plaintext += chr(plainchar)
                else:
                    cipherchar = ord(char) - 65
                    keychar = ord(key[key_index].upper()) - 65
                    plainchar = (cipherchar - keychar) % alpha_length
                    plainchar = plainchar + 65
                    plaintext += chr(plainchar)

                key_index += 1
            else:
                plaintext += char

        return plaintext

    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Vigenerex Cipher
                        Swapt then Vigenere
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert type(plaintext) == str, 'invalid plaintext'
        plaintext = self.encrypt_swapt(plaintext)
        plaintext = self.encrypt_vigenere(plaintext)
        return plaintext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryptoin using Vigenerex Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid ciphertext'
        ciphertext = self.decrypt_vigenere(ciphertext)
        ciphertext = self.decrypt_swapt(ciphertext)
        return ciphertext
    
    @staticmethod
    def cryptanalyze(ciphertext):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
        Return:       key,plaintext
        Description:  Cryptanalysis of Vigenerex cipher
                      Returns vigenerex key and recovered plaintext
                      if process fails: return '',''
        ---------------------------------------------------
        """
        dictionary = utilities.dictionary_to_list('engmix.txt')
        threshold = 0.9
        key_length = 2
        key = ''
        plaintext = ''

        for i in range(26):
            for j in range(26):
                current_key = chr(97 + i) + chr(97 + j)
                vigenerex = Vigenerex(current_key)
                decrypted_text = vigenerex.decrypt(ciphertext)
                if utilities.is_plaintext(decrypted_text, dictionary, threshold):
                    key = current_key
                    plaintext = decrypted_text
                    return key, plaintext

        return key, plaintext

#-------------------- Task 3: Simple Substitution ----------------------
# There is no code needed. 
# You need to use the debug tool defined in the utilities file
# Produce a log file 
# Also write your recovered plaintext into plaintext3_first_last.txt file