from math import ceil,sqrt

ENCODINGS = ['lower','upper','alpha','lowernum','uppernum','alphanum',
             'special','nonalpha','B6','BA','pascii','unicode128','unicode256']
ENGLISH_FREQ = [0.08167,0.01492,0.02782, 0.04253, 0.12702,0.02228, 0.02015,
                0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
                0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
                0.00978, 0.0236, 0.0015, 0.01974, 0.00074]
PAD = 'q'
'______________________________________________________________________________'

def debug(ciphertext, size = 200):
    """
    ----------------------------------------------------
    Parameters:   ciphertext (str)
                  size (int): max characters to display in debug console
    Return:       -
    Description:  Debugging tool for Simple Substitution Cipher
                  Supports two commands:
                      replace <char1> with <char2>
                      end
    ---------------------------------------------------
    """
    base_str = 'abcdefghijklmnopqrstuvwxyz ,;-:?.'
    sub_str = ['-' for _ in range(len(base_str))]
    
    try:
        plaintext = ['-' for i in range(len(ciphertext))]
        print('Ciphertext:')
        print(ciphertext[:size])
        print()
        command = input('Debug Mode: Enter Command: ')
        if command == 'end':
            print()
            return
        input('Description: ')
        print()
        
        while command != 'end':
            sub_char = command[8].lower()
            base_char  = command[15].lower()
                
            if base_char in base_str:
                indx = base_str.index(base_char)
                sub_str[indx] = sub_char
            else:
                print('(Error): Base Character does not exist!\n')
    
            print('Base:',end='')
            for i in range(len(base_str)):
                print('{} '.format(base_str[i]),end='')
            print()
            print('Sub :',end='')
            for i in range(len(sub_str)):
                print('{} '.format(sub_str[i]),end='')
            print('\n')
    
            print('ciphertext:')
            print(ciphertext[:size])
            for i in range(len(plaintext)):
                if ciphertext[i].lower() == sub_char:
                    plaintext[i] = base_char
            print('plaintext :')
            print("".join(plaintext[:size]))
            print('\n_______________________________________\n')
            command = input('Enter Command: ')
            if command != 'end':
                input('Description: ')
            print()
    except Exception as e:
        print('Exception in utilities.debug: {}'.format(e))
        print()
    return
'______________________________________________________________________________'

def is_plaintext(text, dictionary_list, threshold=0.9):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  dict_list (list): dictionary list
                  threshold (float): number between 0 to 1
                      default value = 0.9
    Return:       True/False
    Description:  Check if a given file is a plaintext
                  If #matches/#words >= threshold --> True
                      otherwise --> False
                  If invalid threshold, set to default value of 0.9
                  An empty text should return False
                  Assumes a valid dictionary_list is passed
    ---------------------------------------------------
    """
    if text == '':
        return False
    
    result = count_matches(text, dictionary_list)
    
    percentage = result[0]/(result[0]+result[1])
    
    if type(threshold) != float or threshold < 0 or threshold > 1:
        threshold = 0.9 
    
    if percentage >= threshold:
        return True
    return False

'______________________________________________________________________________'

def get_chars(encoding):
    """
    ----------------------------------------------------
    Parameters:   encoding (str) 
    Return:       result (str)
    Description:  Return string containing all characters defined in the given encoding
                  Defined base types:
                      lower: lower case characters
                      upper: upper case characters
                      alpha: upper and lower case characters
                      lowernum: lower case and numerical characters
                      uppernum: upper case and numerical characters
                      alphanum: upper, lower and numerical characters
                      special: punctuation and special characters (no white spaces)
                      nonalpha: special and numerical characters
                      B6: num, lower, upper, space and newline
                      BA: upper + lower + num + special + ' \n'
                      pascii: upper, lower, numerical and special characters
                      unicode128: pascii + few unicode characters
                      unicode256: pascii + many unicode characters
    Errors:       if invalid encoding, print error msg, return empty string
    ---------------------------------------------------
    """
    lower = "".join([chr(ord('a')+i) for i in range(26)])
    upper = lower.upper()
    num = "".join([str(i) for i in range(10)])
    alpha = upper + lower
    special = ''
    for i in range(ord('!'),127):
        if not chr(i).isalnum():
            special+= chr(i)
    
    unicode1 = 'ÄÆÑÓÙÝäß£¥Ø±÷«»×©ŖŴŽģΔΓΠΦΨδϪΩω¶♤∫₡'
    unicode2 = '❤♫☎♨✈☀✂☑✉☆✎♕✍♂♀ϨϾЊжѠ😀😂😌😛😣😎😔😥😱😬😳😸🙄🙈🙌🙏😈✌❌➔➶🌍🌩🌭🌽🍉🌲🍄🍔🍩🍼🍽🎒🎧'
    unicode2 += '⚙⚠⚰⚽⚿⛍⛔⛏⛵⛷🎤⚀⚂⚄♲⚓⚖∋∌∛∧∨∩∪∲∴∵∻≂≄≡≤≥⊂⊃⊄⊞⊠⊤⊥⊻⊼⊿⋇⋈⋉⋐⋓▦◐◍◢◥◪◆◎☂☃☍☁☕☝☠☢☪☹☺♔♖♙♘🎮🏍🏠'
    result = ''
    if encoding == 'lower': #26 chars
        result = lower
    elif encoding == 'upper': #26 chars
        result = upper
    elif encoding == 'alpha': #52 chars
        result = alpha
    elif encoding == 'lowernum': #36 chars
        result = lower + num
    elif encoding == 'uppernum': #36 chars
        result = upper + num
    elif encoding == 'alphanum': #62
        result = alpha + num
    elif encoding == 'special': #32 chars
        result = special
    elif encoding == 'nonalpha': #42
        result = special + num
    elif encoding == 'B6': #64 symbols
        result = alpha + num + ' ' + '\n'
    elif encoding == 'BA': #96 symbols
        result = alpha + num + special + ' \n'
    elif encoding == 'pascii': #94 printable ASCII characters
        result = alpha + num + special
    elif encoding == 'unicode128': #128
        result = alpha + num + special + unicode1
    elif encoding == 'unicode256': #256 chars
        result = alpha + num + special + unicode1 + unicode2
    else:
        print('Error(get_chars): undefined base type')
        result = ''
    return result

'______________________________________________________________________________'
def encode(text,encoding):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  encoding (str)
    Return:       codes (list)
    Description:  encodes given text using the given encoding
                  for each character in text
                    if char in base, find index in base, add to list of codes
                    if char not in base, add char to list of codes
    Errors:       if invalid encoding, print error msg, return empty list
    ---------------------------------------------------
    """
    if encoding not in ENCODINGS:
        print('Error(encode): invalid encoding')
        return []
    base = get_chars(encoding)        
    output = []
    for c in text:
        if c in base:
            output.append(base.index(c))
        else:
            output.append(c)
    return output
'______________________________________________________________________________'
def decode(codes,encoding):
    """
    ----------------------------------------------------
    Parameters:   codes (list)
                  encoding (str)
    Return:       text (str)
    Description:  decodes given codes using the given encoding
                  for each item in codes
                    if item is a number within the base length, 
                        find corresponding char, add to output text
                    if item is str, add char to output text
    Errors:       if invalid encoding, print error msg, return empty string
    ---------------------------------------------------
    """
    if encoding not in ENCODINGS:
        print('Error(decode): invalid encoding')
        return ''
    base = get_chars(encoding)
    output = ''
    for c in codes:
        if type(c) == int and c < len(base):
            output += base[c]
        elif type(c) == str:
            output += c
    return output
'______________________________________________________________________________'

def file_to_text(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       contents (str)
    Description:  Utility function to read contents of a file
                  Can be used to read plaintext or ciphertext
    Asserts:      filename is a valid name
    ---------------------------------------------------
    """
    assert is_valid_filename(filename), 'invalid filename'
    infile = open(filename,'r')
    contents = infile.read()
    infile.close()
    return contents

'______________________________________________________________________________'

def text_to_file(text, filename):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  filename (str)            
    Return:       no returns
    Description:  Utility function to write any given text to a file
                  If file already exist, previous contents will be erased
    Asserts:      text is a string and filename is a valid filename
    ---------------------------------------------------
    """
    assert type(text) == str , 'invalid text'
    assert is_valid_filename(filename), 'invalid filename'
    outfile = open(filename,'w')
    outfile.write(text)
    outfile.close()
    return

'______________________________________________________________________________'

def is_valid_filename(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       True/False
    Description:  Checks if given input is a valid filename 
                  a filename should have at least 3 characters
                  and contains a single dot that is not the first or last character
    ---------------------------------------------------
    """
    if type(filename) != str:
        return False
    if len(filename) < 3:
        return False
    if '.' not in filename:
        return False
    if filename[0] == '.' or filename[-1] == '.':
        return False
    if filename.count('.') != 1:
        return False
    return True

'______________________________________________________________________________'


def load_dictionary(dict_file=None):
    """
    ----------------------------------------------------
    Parameters:   dict_file (str): filename
                        default value = None
    Return:       dict_list (list): 2D list
    Description:  Reads a given dictionary file
                  dictionary is assumed to be formatted as each word in a separate line
                  Returns a list of lists, list 0 contains all words starting with 'a'
                  list 1 all words starting with 'b' and so forth.
                  if no parameter given, use default file (DICT_FILE)
    Errors:       if invalid filename, print error msg, return []
    ---------------------------------------------------
    """
    if dict_file == None:
        dict_file = DICT_FILE

    if not is_valid_filename(dict_file):
        print('Error(load_dictionary): invalid filename')
        return []

    alphabet = get_base('lower')
    infile = open(dict_file, 'r', encoding=" ISO-8859-15")
    dict_words = infile.readlines()
    dict_list = [[] for _ in range(26)]
    for w in dict_words:
        word = w.strip('\n')
        dict_list[alphabet.index(word[0])] += [word]
    infile.close()
    return dict_list


'______________________________________________________________________________'


def load_dictionary(dict_file=None):
    """
    ----------------------------------------------------
    Parameters:   dict_file (str): filename
                        default value = None
    Return:       dict_list (list): 2D list
    Description:  Reads a given dictionary file
                  dictionary is assumed to be formatted as each word in a separate line
                  Returns a list of lists, list 0 contains all words starting with 'a'
                  list 1 all words starting with 'b' and so forth.
                  if no parameter given, use default file (DICT_FILE)
    Errors:       if invalid filename, print error msg, return []
    ---------------------------------------------------
    """
    if dict_file == None:
        dict_file = DICT_FILE

    if not is_valid_filename(dict_file):
        print('Error(load_dictionary): invalid filename')
        return []

    alphabet = get_base('lower')
    infile = open(dict_file, 'r', encoding=" ISO-8859-15")
    dict_words = infile.readlines()
    dict_list = [[] for _ in range(26)]
    for w in dict_words:
        word = w.strip('\n')
        dict_list[alphabet.index(word[0])] += [word]
    infile.close()
    return dict_list


'______________________________________________________________________________'

def dictionary_to_list(dictionary_file):
    """
    ----------------------------------------------------
    Parameters:   dictionary_file (str): filename
    Return:       dict_list (list): 2D list
    Description:  Reads a given dictionary file
                  dictionary is assumed to be formatted as each word in a separate line
                  Returns a list of lists, list 0 contains all words starting with 'a'
                  list 1 all words starting with 'b' and so forth.
    Errors:       if invalid filename, print error msg, return []
    ---------------------------------------------------
    """   
    alphabet = get_chars('lower')
    try:
        infile = open(dictionary_file, 'r',encoding=" ISO-8859-15") 
        dict_words = infile.readlines()
        dict_list = [[] for _ in range(26)]
        for w in dict_words:
            word = w.strip('\n')
            dict_list[alphabet.index(word[0])]+=[word]
        infile.close()
    except FileNotFoundError:
        print('Error(dictionary_to_list): failed to open given file')
        dict_list = []
    return dict_list
'______________________________________________________________________________'

def text_to_words(text):
    """
    ----------------------------------------------------
    Parameters:   text (str)
    Return:       word_list (list)
    Description:  Reads a given text
                  Returns a list of strings, each pertaining to a word in the text
                  Words are separated by a white space (space, tab or newline)
                  Gets rid of all special characters at the start and at the end
    Asserts:      text is a string
    ---------------------------------------------------
    """
    assert type(text) == str, 'invalid input'
    special = get_chars('special')
    word_list = []
    lines = text.split('\n')
    for line in lines:
        line = line.strip('\n')
        line = line.split(' ')
        for i in range(len(line)):
            if line[i] != '':
                line[i] = line[i].strip(special)
                word_list+=[line[i]]
    return word_list

'______________________________________________________________________________'

def count_matches(text, word_list):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  word_list (list)
    Return:       matches (int)
                  mismatches (int)
    Description:  Reads a given text, checks if each word appears in given word_list
                  Returns number of matches and mismatches.
                  Words are compared in lowercase
                  Assumes word_list is 2D (output of dictionary_to_list)
    Asserts:      text is a string and dict_list is a list
    ---------------------------------------------------
    """
    assert type(text) == str and type(word_list) == list, 'invalid input'
    words = text_to_words(text)
    alphabet = get_chars('lower')
    matches = 0
    mismatch = 0
    for w in words:
        if w.isalpha():
            list_num = alphabet.index(w[0].lower())
            if w.lower() in word_list[list_num]:
                matches+=1
            else:
                mismatch+=1
        else:
            mismatch+=1
    return matches,mismatch

'______________________________________________________________________________'

def shift_string(s,n,d='l'):
    """
    ----------------------------------------------------
    Parameters:   text (string): input string
                  shifts (int): number of shifts
                  direction (str): 'l' or 'r'
    Return:       update_text (str)
    Description:  Shift a given string by given number of shifts (circular shift)
                  If shifts is a negative value, direction is changed
                  If no direction is given or if it is not 'l' or 'r' set to 'l'
    Asserts:      text is a string and shifts is an integer
    ---------------------------------------------------
    """
    assert type(s) == str and type(n) == int
    if d != 'r' and d!= 'l':
        d = 'l'
    if n < 0:
        n = n*-1
        d = 'l' if d == 'r' else 'r'
    n = n%len(s)
    if s == '' or n == 0:
        return s

    s = s[n:]+s[:n] if d == 'l' else s[-1*n:] + s[:-1*n]
    return s

'______________________________________________________________________________'

def matrix_to_str(matrix):
    """
    ----------------------------------------------------
    Parameters:   matrix (2D List)
    Return:       text (string)
    Description:  convert a 2D list of characters to a string
                  from top-left to right-bottom
                  Assumes given matrix is a valid 2D character list
    ---------------------------------------------------
    """
    text = ""
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            text+=matrix[i][j]
    return text

'______________________________________________________________________________'

def get_positions(text,base):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  base (str):  stream of unique characters
    Return:       positions (2D list)
    Description:  Analyzes a given text for any occurrence of base characters
                  Returns a 2D list with characters and their respective positions
                  format: [[char1,pos1], [char2,pos2],...]
                  Example: get_positions('I have 3 cents.','c.h') -->
                      [['h',2],['c',9],['.',14]]
                  items are ordered based on their occurrence in the text
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    assert type(text) == str and type(base) == str, 'invalid input'
    positions = []
    for i in range(len(text)):
        if text[i] in base:
            positions.append([text[i],i])
    return positions

'______________________________________________________________________________'

def clean_text(text,base):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str)
    Return:       updated_text (str)
    Description:  Constructs and returns a new text which has
                  all characters in original text after removing base characters
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    assert type(text) == str and type(base) == str, 'invalid input'
    updated_text = ''
    for char in text:
        if char not in base:
            updated_text += char
    return updated_text

'______________________________________________________________________________'

def insert_positions(text, positions):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  positions (list): [[char1,pos1],[char2,pos2],...]]
    Return:       updated_text (str)
    Description:  Inserts all characters in the positions 2D list (generated by get_positions)
                  into their respective locations
                  Assumes a valid positions 2d list is given
    Asserts:      text is a string and positions is a list
    ---------------------------------------------------
    """
    assert type(text) == str and type(positions) == list, 'invalid input'
    updated_text = text
    for item in positions:
        updated_text = updated_text[:item[1]]+ item[0] + updated_text[item[1]:]
    return updated_text

'______________________________________________________________________________'

def text_to_blocks(text,b_size,padding = False,pad =PAD):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  block_size (int)
                  padding (bool): False(default) = no padding, True = padding
                  pad (str): padding character, default = PAD
    Return:       blocks (list)
    Description:  Create a list containing strings each of given block size
                  if padding flag is set, pad empty blocks using given padding character
                  if no padding character given, use global PAD
    Asserts:      text is a string and block_size is a positive integer
    ---------------------------------------------------
    """
    assert type(text) == str and type(b_size) == int and b_size > 0, 'invalid input'
    
    blocks = [text[i*b_size:(i+1)*b_size] for i in range(ceil(len(text)/b_size))]
    
    if padding:
        if (len(blocks) == 1 and len(blocks[0]) < b_size) or \
            len(blocks) > 1 and len(blocks[-1]) < len(blocks[0]):
                blocks[-1] += pad*(b_size - len(blocks[-1]))
    
    return blocks

'______________________________________________________________________________'

def blocks_to_baskets(blocks):
    """
    ----------------------------------------------------
    Parameters:   blocks (list): list of equal size strings
    Return:       baskets: (list): list of equal size strings
    Description:  Create k baskets, where k = block_size
                  basket[i] contains the ith character from each block
    Errors:       if blocks are not strings or are of different sizes -->
                    print 'Error(blocks_to_baskets): invalid blocks', return []
    ----------------------------------------------------
    """
    valid_input = True
    if type(blocks) != list or list == []:
        valid_input = False
    else:
        for b in blocks:
            if type(b) != str:
                valid_input = False
                break
        if valid_input:
            n = len(blocks[0])
            for b in blocks:
                if len(b) != n:
                    valid_input = False
                    break
    
    baskets = []
    if valid_input:      
        n = len(blocks[0])
        for j in range(n):
            basket = ''
            for i in range(len(blocks)):
                if j < len(blocks[i]):
                    basket+=blocks[i][j]
            baskets.append(basket)
    else:
        print('Error(blocks_to_baskets): invalid blocks')
    return baskets

'______________________________________________________________________________'

def compare_texts(text1,text2):
    """
    ----------------------------------------------------
    Parameters:   text1 (str)
                  text2 (str)
    Return:       matches (int)
    Description:  Compares two strings and returns number of matches
                  Comparison is done over character by character
    Assert:       text1 and text2 are strings
    ----------------------------------------------------
    """
    assert type(text1) == str and type(text2) == str, 'invalid input'
    counter = 0
    matches = 0
    while counter < len(text1) and counter <len(text2):
        if text1[counter] == text2[counter]:
            matches += 1
        counter +=1
    return matches

'______________________________________________________________________________'

def frequency_analysis(text,base = ''):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str): default = ''
    Return:       count_list (list of floats) 
    Description:  Finds character frequencies (count) in a given text
                  Default is English language (counts both upper and lower case)
                  Otherwise returns frequencies of characters defined in base
    Assert:       text is a string
    ----------------------------------------------------
    """
    assert type(text) == str , 'invalid input'
    if base == None:        
        return [text.count(chr(97+i))+text.count(chr(65+i)) for i in range(26)]
    return [text.count(char) for char in base]

'______________________________________________________________________________'
class MOD:
    """
    ----------------------------------------------------
    Description: Some utility functions for modular arithmetic
    ----------------------------------------------------
    """
    @staticmethod
    def is_prime(n):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   n (int): an arbitrary integer
        Return:       True/False
        Description:  Check if the given input is a prime number
                      Search Online for an efficient implementation
        ---------------------------------------------------
        """
        if not isinstance(n,int):
            return False
        if n > 1:
            if n ==2:
                return True
            if n %2 == 0:
                return False
            for i in range(3,int(sqrt(n)+1),2):
                if n%i == 0:
                    return False
            return True
        return False

    @staticmethod
    def gcd(a,b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (int): gcd(a,b)
        Description:  Computes and returns the greatest common divider using
                      the standard Eculidean Algorithm.
                      The implementation can be iterative or recursive
        Errors:       if a or b are non positive integers, return:
                        'Error(MOD.gcd): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a,int) or not isinstance(b,int) or b == 0 or a == 0:
            return 'Error(MOD.gcd): invalid input'
        if a < 0 or b < 0:
            return MOD.gcd(abs(a),abs(b))
        if b > a:
            return MOD.gcd(b,a)
        if a % b == 0:
            return b
        return MOD.gcd(b, a%b)

    @staticmethod
    def is_relatively_prime(a,b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       True/False
        Description:  Check if <a> and <b> are relatively prime
                          i.e., gcd(a,b) equals 1
        Errors:       if <a> or <b> are non positive integers, return:
                        'Error(Mod.is_relatively_prime): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a,int) or not isinstance(b,int):
            return 'Error(MOD.is_relatively_prime): invalid input'
        if a == 0 or b == 0:
            return False
        if MOD.gcd(a,b) == 1:
            return True
        return False

    @staticmethod
    def has_mul_inv(a,m):
        """
        ----------------------------------------------------
        Parameters:   a (int): an arbitrary positive integer
                      m (int): an arbitrary positive integer
        Return:       True/False
        Description:  Check if <a> has a multiplicative inverse mod <m>
        ---------------------------------------------------
        """
        return MOD.is_relatively_prime(a,m)

    @staticmethod
    def EEA(a,b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (list): [gcd(a,b), s, t]
        Description:  Uses Extended Euclidean Algorithm to find:
                        gcd(a,b) and <s> and <t> such that:
                        as + bt = gcd(a,b), i.e., Bezout's identity
        Errors:       if a or b are 0 or non-integers
                        'Error(MOD.EEA): invalid input'
        ---------------------------------------------------
        """
        if type(a) != int or type(b) != int or a == 0 or b == 0:
            return 'Error(MOD.EEA): invalid input'
        u = [abs(a), 1, 0]
        v = [abs(b), 0, 1]
        r = [0,0,0]
        while v[0] != 0:
            q = u[0]//v[0]
            r = [u[0] - q*v[0], u[1]-q*v[1], u[2]-q*v[2]]
            u = v
            v = r
        return u

    @staticmethod
    def get_mul_inv(a,m):
        """
        ----------------------------------------------------
        Parameters:   a (int): an arbitrary positive integer
                      m (int): an arbitrary positive integer
        Return:       mul_inv (int or 'NA')
        Description:  Computes and returns the multiplicative inverse of 
                        current of a mod m
                      if it does not exist returns 'NA'
        Errors:       if a is not a positive integer, or
                      m is not an integer > 1 --> 
                      return 'Error(MOD.get_mult_inv): invalid input'
        ---------------------------------------------------
        """
        if type(a) != int or a <= 0:
            return 'Error(MOD.get_mult_inv): invalid input'
        if type(m) != int or m <= 1:
            return 'Error(MOD.get_mult_inv): invalid input'
        mul_v = 'NA'
        a = a % m
        if a!= 0 and MOD.has_mul_inv(a,m):
            _,s,_ = MOD.EEA(a,m)
            mul_v = s%m
        return mul_v