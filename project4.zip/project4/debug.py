from utilities import file_to_text, text_to_file
from exam2 import NAME

def debug(ciphertext):
    base_str = 'abcdefghijklmnopqrstuvwxyz ,;-:?.'
    sub_str = ['-' for _ in range(len(base_str))]
    counter = 1
    plaintext = []
    for c in ciphertext:
        if c.lower() not in base_str:
            plaintext.append(c)
        else:
            plaintext.append('-')
            
    print('Ciphertext:')
    print(ciphertext)
    print('\n_______________________________________\n')
    
    print('Round {}'.format(counter))
    command = input('Debug Mode: Enter Command: ')
    
    while command != 'end':
        print('Description: ')
        print()
        sub_char = command[8].lower()
        base_char = command[15].lower()
            
        if base_char in base_str:
            indx = base_str.index(base_char)
            sub_str[indx] = sub_char
        else:
            print('(Error): Base Character does not exist!\n')

        print('Base:',end='')
        for i in range(len(base_str)):
            print('{} '.format(base_str[i]),end='')
        print()
        print('Sub :',end='')
        for i in range(len(sub_str)):
            print('{} '.format(sub_str[i]),end='')
        print('\n')

        for i in range(len(plaintext)):
            if ciphertext[i].lower() == sub_char:
                plaintext[i] = base_char
                if ciphertext[i].isupper():
                    plaintext[i] = plaintext[i].upper()
        print('plaintext :')
        print("".join(plaintext[:200]))
        print('\n_______________________________________\n')
        counter += 1
        print('Round {}'.format(counter))
        command = input('Enter Command: ')

    print('completed debugging')
    return ''.join(plaintext)

def get_plaintext3():
    cipherfile = 'ciphertext3_'+NAME+'.txt'
    ciphertext = file_to_text(cipherfile)
    plaintext = debug(ciphertext)
    plainfile = 'plaintext3_'+NAME+'.txt'
    text_to_file(plaintext,plainfile)
    return

get_plaintext3()