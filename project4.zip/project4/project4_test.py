from exam2 import NAME, exam_info, Mathx, Vigenerex
import utilities

def get_info():
    try:
        print('{}'.format('-'*40))
        print("Retrieving student info:")
        print()
        print('Name: {} {}'.format(exam_info.get_first_name(), exam_info.get_last_name()))
        print('ID: {}'.format(exam_info.get_ID()))
        print('filename = {}'.format(NAME))
        print()
        print(exam_info.get_certification())
        print()
        print(exam_info.get_comments())
        print()
        print('{}'.format('-'*40))
        print()
    except Exception as e:
        print('Exception by get_info: {}'.format(e))
    return

def test_task1():
    print('{}'.format('-'*40))
    print("Start of Mathx Testing")
    print()

    try:
        print('--- Creating a Math_Cipher object using default constructor ---')
        mcipher = Mathx()
        print(mcipher)
        print()
        
        print('--- Testing Mathx.valaid_key ---')
        cases = [[15,17,3,9,12],(15,17,3),(15,8,'13',9,13),(15,8,13,-1,14),(15,8,7,21,7),(11,0,13,0,26),
                 (12,7,13,0,26),(9,2,3,0,14),(12,15,14,0,116),(2,1,6,15,16),(11,9,1,2,44),(11,7,13,0,26),
                 (9,15,0,0,29),(9,15,1,2,43),(17,29,6,12,69)]
        for c in cases:
            print('{:20s} --> {}'.format(str(c), Mathx.valid_key(c)))
        print()
    except Exception as e:
        print('Exception in Testing Mathx.valid key: {}'.format(e))
    
    try:    
        print('--- Testing __str__, set_key, get_key and get_base ---')
        cases = [(11,5,1,26,52),(130,127,92,6,43),(-5,22,9,0,71),(11,5,3,0,26)]
        for c in cases:
            print('Setting Mathx key to {}'.format(c))
            print('\tset_key success = {}'.format(mcipher.set_key(c)))
            print('\tget_key = {}'.format(mcipher.get_key()))
            print('\tget_base = {}'.format(mcipher.get_base()))
            print(mcipher)
            print()
    except Exception as e:
        print('Exception in Testing Mathx basics: {}'.format(e))    
    
    try:    
        print('--- Testing mathx.encrypt and mathx.decrypt ---')
        
        plaintexts = ['Strike in progress', 'Is mission accomplished?', 'Mission Failed!', 
                      'caesar cipher']
        keys = [(5,9,11,26,52),(45,3,14,0,49),(10,19,14,2,91),(0,1,2,26,72)]
        
        for i in range(len(keys)):
            k = keys[i]
            plaintext = plaintexts[i]
            mcipher.set_key(k)
            print(mcipher)
            print('plaintext =  ', plaintext)
            ciphertext = mcipher.encrypt(plaintext)
            print('ciphertext=  ',ciphertext)
            plaintext2 = mcipher.decrypt(ciphertext)
            print('plaintext2=  ',plaintext2)
            print()
    except Exception as e:
        print('Exception in Testing Mathx encrypt and decrypt: {}'.format(e))
    
    try:    
        print('----- Testing mathx.classify:')    
        keys = [(15,5,3,71,87),(1,0,0,75,79),(19,4,13,42,75),(30,31,30,20,91),
                (3,0,2,74,78),(0,3,0,2,13),(6,2,2,49,56),(0,0,2,86,89),
                (2,2,1,84,88),(9,17,5,67,93),(8,4,11,14,26),(22,0,21,19,65),
                (9, 17, 13, 44, 64),(32, 32, 21, 0, 40),(1, 2, 2, 86, 91)]
        for key in keys:
            mcipher.set_key(key)
            print('{:20s} is {}'.format(str(key),mcipher.classify()))
        print()
    except Exception as e:
        print('Exception in Testing mathx classify: {}'.format(e))
    
    try:        
        print('--- Testing Mathx.analyze_keydomain')
        cases = [(0,2),(26,29),(50,54),(60,65),(11,54)]
        for c in cases:
            print('Analyzing Base = {}:'.format(Mathx.BASE[c[0]:c[1]]))
            counters = Mathx.analyze_keydomain(c)
            total = sum(counters)
            print('   total keys      = {:5d} keys'.format(total))
            print('   No encipherment = {:5d} keys = %{:.2f}'.format(counters[0],counters[0]*100/total))
            print('   Shift           = {:5d} keys = %{:.2f}'.format(counters[1],counters[1]*100/total))        
            print('   Decimation      = {:5d} keys = %{:.2f}'.format(counters[2],counters[2]*100/total))
            print('   Affine          = {:5d} keys = %{:.2f}'.format(counters[3],counters[3]*100/total))
            print('   Invalid         = {:5d} keys = %{:.2f}'.format(counters[4],counters[4]*100/total))
            print()
    except Exception as e:
        print('Exception in Testing Mathx.analyze_keydomain: {}'.format(e))
                
    try:
        print('----------- cryptanalysis on sample data:')
        plaintext = 'There are two kinds of cryptography in this world: '
        plaintext += 'cryptography that will stop your kid sister from reading your files, '
        plaintext += 'and cryptography that will stop major governments from reading your files.'
        
        key = (2,23,1,0,59)
        mcipher.set_key(key)
        # print(mcipher.get_key())
        ciphertext = mcipher.encrypt(plaintext)
        print('plaintext  = {}'.format(plaintext))
        print('ciphertext = {}'.format(ciphertext))
        key,plaintext2 = Mathx.cryptanalyze(ciphertext)
        print('plaintext2 = {}'.format(plaintext2))
        print('key = {}'.format(key))
        print()
        
        info = exam_info()
        print('Testing student file:')
        cipher_file = 'ciphertext1_' + NAME + '.txt'
        ciphertext = utilities.file_to_text(cipher_file)
        print('ciphertext = {}'.format(ciphertext[:50]))
        
        #comment out this line if you want to do slow-testing
        # key,plaintext = Mathx.cryptanalyze(ciphertext)
        
        #These lines are for fast testing
        key,plaintext = info.get_task1_solution()
        
        print('plaintext  = {}'.format(plaintext))
        print('key = {}'.format(key))
        
    except FileNotFoundError:
        print('Exception: {} is not found'.format(cipher_file))
    except Exception as e:
        print('Exception by Task 1: {}'.format(e))
    finally:
        print()
        
    print('End of Task1 Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_task2():
    print('{}'.format('-'*40))
    print("Start of Task 2: Vigenerex Testing")
    print()

    try:
        print('--- Testing Vigenrex.valid_key ---')
        keys = [15,'a','BC','dE','f?','ghi','jk','mm']
        for k in keys:
            print('{:3s} --> {}'.format(str(k),Vigenerex.valid_key(k)))
        print()
        
        print('--- default constructor ---')
        v = Vigenerex()
        print(v)
        print()
        
        print('--- Testing __str__, set_key and get_key ---')
        keys = ['yc','Ok']
        for k in keys:
            print('vigenerex.set_key({}) = '.format(k),end='')
            print(v.set_key(k))
            print('vigenerex.get_key() = {}'.format(v.get_key()))
            print(v)
            print()
    except Exception as e:
        print('Exception in basic testing: {}'.format(e))
    
    try:    
        print('--- Testing swapt cipher ---')
        plaintexts = ['LOCALGUARDS', 'rulesofengagement',
                      'Swapt Cipher is a simple transposition scheme',
                      '[Vigenere Cipher] is a "Polyalphabetic Substitution" Cipher.']
        for plaintext in plaintexts:
            print('plaintext  = {}'.format(plaintext))
            ciphertext = v.encrypt_swapt(plaintext)
            print('ciphertext = {}'.format(ciphertext))
            plaintext2 = v.decrypt_swapt(ciphertext)
            print('plaintext2 = {}'.format(plaintext2))
            print()
    except Exception as e:
        print('Exception in Testing swapt: {}'.format(e))
    
    try:            
        print('--- Testing Vigenere cipher ---')
        for plaintext in plaintexts:
            print('plaintext  = {}'.format(plaintext))
            ciphertext = v.encrypt_vigenere(plaintext)
            print('ciphertext = {}'.format(ciphertext))
            plaintext2 = v.decrypt_vigenere(ciphertext)
            print('plaintext2 = {}'.format(plaintext2))
            print()
    except Exception as e:
        print('Exception in Testing Vigenere: {}'.format(e))
        
    try:
        print('--- Testing Vigenerex cipher ---')
        for plaintext in plaintexts:
            print('plaintext  = {}'.format(plaintext))
            ciphertext = v.encrypt(plaintext)
            print('ciphertext = {}'.format(ciphertext))
            plaintext2 = v.decrypt(ciphertext)
            print('plaintext2 = {}'.format(plaintext2))
            print()
    except Exception as e:
        print('Exception in Testing Vigenerex: {}'.format(e))
                
    try:
        print('--- cryptanalysis over sample data ---')
        ciphertext = 's kcyOlwur :wfqfm zFzms fsnsa usdj igjk ogfjmwgf hv bgkgma,'
        ciphertext += 'ufsvifcfs xwdq qrafffm oko xperem esdwwgj'
        print('ciphertext = {}'.format(ciphertext))
        key,plaintext = Vigenerex.cryptanalyze(ciphertext)
        print('plaintext2 = {}'.format(plaintext))
        print('key = {}'.format(key))
        print()
    
        info = exam_info()
        print('Testing student file:')
        cipher_file = 'ciphertext2_' + NAME + '.txt'
        ciphertext = utilities.file_to_text(cipher_file)
        print('ciphertext = {}'.format(ciphertext[:50]))
        
        #comment out this line if you want to do slow-testing
        # key,plaintext = Vigenerex.cryptanalyze(ciphertext)
        
        #These lines are for fast testing
        key,plaintext = info.get_task2_solution()
        v.set_key(key)
        plaintext = v.decrypt(ciphertext)
        
        print('key = {}'.format(key))
        print('plaintext2 = {}'.format(plaintext[:50]))

    except FileNotFoundError:
        print('Exception: {} is not found'.format(cipher_file))
    except Exception as e:
        print('Exception in Vigenerex cryptanalysis: {}'.format(e))
    finally:
        print()
        
    print('End of Task 2: Vigenerex Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_task3():
    print('{}'.format('-'*40))
    print("Start of Task 3: Substitution Puzzle Testing")
    print()

    try:
        filename = 'ciphertext3_' + NAME + '.txt'
        utilities.file_to_text(filename)
        key,plaintext = exam_info.get_task3_solution()
        print('key = {}'.format(key))
        print('plaintext = {}'.format(plaintext[:200]))

    except FileNotFoundError:
        print('Exception: {} is not found'.format(filename))
    except Exception as e:
        print('Exception by Task 3: {}'.format(e))
    finally:
        print()
    
    print('End of Task 3: Substitution Puzzle Testing')
    print('{}'.format('-'*40))
    print()
    return
    
# get_info()
test_task1()
# test_task2()
# test_task3()
