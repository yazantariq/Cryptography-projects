from A2 import Wheatstone
from utilities import dictionary_to_list, file_to_text

def test_wheatstone_key():
    print('{}'.format('-'*40))
    print("Start of Wheatstone Key Testing")
    print()
    
    print('Testing valid key:')
    cases = [[0,25,'BR'],(0,25),('a',25,'BR'),(-2,25,'BR'),(100,25,'BR'),
             (0,'a','BR'),(2,25,'BT'),(21,81,'TR'),(80,25,'TR'),
             (0,9,'BR'),(1,81,'TR'),(2,36,'BL'),(80,9,'TL')]
    for c in cases:
        print('Valid_key({}) = {}'.format(c,Wheatstone.valid_key(c)))
    print()
    
    print('End of Wheatstone Key Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_wheatstone_basics():
    print('{}'.format('-'*40))
    print("Start of Wheatstone Basic Testing")
    print()
    
    print('Test Default Constructor:')
    w = Wheatstone()
    print('w.get_key() = {}'.format(w.get_key()))
    print('w.get_base() = {}'.format(w.get_base()))
    print()
    
    keys = [(0,9,'BR'),(14,64,'BL'),(21,81,'TR')]
    print('Testing set_key and get_key:')
    for k in keys:
        print('set_key({}) = {}'.format(k,w.set_key(k)))
        print('get_key = {}'.format(w.get_key()))
        print()
    
    print('Testing set_pad and get_pad:')
    pads = ['','Z','x','xx',3]
    for pad in pads:
        print('set_pad({}) = {}, get_pad = {}'.format(pad,w.set_pad(pad), w.get_pad()))
    print()
       
    print('End of Wheatstone Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_wheatstone_base():
    print('{}'.format('-'*40))
    print("Start of Wheatstone Base Testing")
    print()
    
    w = Wheatstone()
    
    keys = [(16,49,'BR'),(14,64,'BL'),(6,81,'TR')]
    print('Testing get_base:')
    for k in keys:
        w.set_key(k)
        print('key = {}'.format(w.get_key()))
        print('get_base = {}'.format(w.get_base()))
        print('unused_chars = {}'.format(w.get_unused_chars()))
        print()

    print('End of Wheatstone Base Testing')
    print('{}'.format('-'*40))
    print()
    return
            
def test_wheatstone_table():
    print('{}'.format('-'*40))
    print("Start of Wheatstone Table Testing")
    print()

    cases = [(0,25,'TL'),(0,25,'TR'),(0,25,'BL'),(0,25,'BR'),
             (14,36,'TL'),(14,36,'TR'),(14,36,'BL'),(14,36,'BR')]
    w = Wheatstone()

    print('Testing get_table:')
    for c in cases:
        print('key = {}'.format(c))
        w.set_key(c)
        print(w.get_table())
        print()
        
    print('Testing print_table:')
    for c in cases:
        print('key = {}'.format(c))
        w.set_key(c)
        w.print_table()
        print()

    print('Testing __str__:')
    w2 = Wheatstone()
    print(w2)
    print()

    w2.set_key((14,64,'BL'))
    w2.set_pad('X')
    print(w2)
    print()
    
    print('End of Wheatstone Table Testing')
    print('{}'.format('-'*40))
    print()
    return
  
def test_encrypt1():
    print('{}'.format('-'*40))
    print("Start of Wheatstone encrypt [1] Testing")
    print()
    
    w = Wheatstone()
    w.set_pad('z')
    print(w)
    print()
    
    plaintexts = ['gi','qr','nk','rh','sl','pe','gc','mq','oi','vp','az']
    for p in plaintexts:
        print('plain = {}, cipher = {}'.format(p,w.encrypt(p)))
    print()
    
    w.set_key((15,64,'TR'))
    print(w)
    print()
    
    plaintexts = ['LH','32','zF','Q7','CJ','6-','EM','LZ',',p']
    for p in plaintexts:
        print('plain = {}, cipher = {}'.format(p,w.encrypt(p)))
    print()
        
    print('End of Wheatstone encrypt [1] Testing')
    print('{}'.format('-'*40))
    print()
    return 

def test_decrypt1():
    print('{}'.format('-'*40))
    print("Start of Wheatstone decrypt [1] Testing")
    print()
    
    w = Wheatstone()
    w.set_pad('z')
    print(w)
    print()
    
    ciphertexts = ['hj','rs','mo','mc','li','oz','hd','nr','lf','zs','eu']
    for c in ciphertexts:
        print('cipher = {}, plain = {}'.format(c,w.decrypt(c)))
    print()
    
    w.set_key((15,64,'TR'))
    print(w)
    print()
    
    ciphertexts = ['KG','21','Ay','2)','JS','*v','zH','I2','=x']
    for c in ciphertexts:
        print('cipher = {}, plain = {}'.format(c,w.decrypt(c)))
    print()
        
    print('End of Wheatstone decrypt [1] Testing')
    print('{}'.format('-'*40))
    print()
    return 

def test_encrypt2():
    print('{}'.format('-'*40))
    print("Start of Wheatstone encrypt [2] Testing")
    print()
    
    w = Wheatstone()
    w.set_pad('z')
    print(w)
    print()
    
    plaintexts = ['rr','c','m-m','aabb','abba','concessions', 'Best Match',
                  'Introduction to Cryptography']
    for p in plaintexts:
        print('plain = {} --> {}, cipher = {}'.format(p,w.preprocess_plaintext(p),w.encrypt(p)))
    print()
    
    w.set_key((8,49,'TL'))
    w.set_pad('0')
    print(w)
    print()
    
    plaintexts = ['GO OUT OF YOUR COMFORT ZONE','Why did you get married too late?',
                  'SMILING IS A FORM OF CHARITY']
    for p in plaintexts:
        print('plaintext = {}'.format(p))
        print('processed = {}'.format(w.preprocess_plaintext(p)))
        print('ciphertext= {}'.format(w.encrypt(p)))
        print()

    print('End of Wheatstone encrypt [2] Testing')
    print('{}'.format('-'*40))
    print()
    return 

def test_decrypt2():
    print('{}'.format('-'*40))
    print("Start of Wheatstone decrypt [2] Testing")
    print()
    
    w = Wheatstone()
    w.set_pad('z')
    print(w)
    print()
    
    ciphertexts = ['mr','ex','h-r','cucv','eaae','emmdbplbnmpv','Bbpk Murafx',
                   'Ikqpmayarflk qm Cpzqpkhqetgx']
    for c in ciphertexts:
        print('cipher = {}, plain = {}'.format(c,w.decrypt(c)))
    print()
    
    w.set_key((8,49,'TL'))
    w.set_pad('0')
    print(w)
    print()
    
    ciphertexts = ['HP PVV QJ TPVQ DPNHQQS VLRI',
                   'UVhx djd Djt ges raBvmed pki mave?2',
                   'YRKNNXF HV D HQLN QH AFDOFXZ1']
    for c in ciphertexts:
        print('ciphertext = {}'.format(c))
        print('plaintext  = {}'.format(w.decrypt(c)))
        print()

    print('End of Wheatstone decrypt [2] Testing')
    print('{}'.format('-'*40))
    print()
    return 

def test_wheatstone_plaintext_preprocessing():
    print('{}'.format('-'*40))
    print("Start of Wheatstone Plaintext Processing Testing")
    print()
    
    print('Case 1:')
    w = Wheatstone()
    w.set_pad('z')
    print(w)
    plaintexts = ['part','light','lesson','door','floor','c','window','Widow','worried',
                  'shallow','hallow','Ramadan','March?','February?','are you happy?',
                  'Are you happy?','Wow!! That is wonderful!','bad work','volvo','cows',
                  'the-book-keeping']
    for i in range(len(plaintexts)):
        print('{:24s}\t{}'.format(plaintexts[i],w.preprocess_plaintext(plaintexts[i])))
    print()
    
    print('Case 2:')
    w.set_key((15,49,'TR'))
    w.set_pad('#')
    print(w)
    for i in range(len(plaintexts)):
        print('{:24s}\t{}'.format(plaintexts[i],w.preprocess_plaintext(plaintexts[i])))
    print()
    
    print('End of Wheatstone Plaintext Processing Testing')
    print('{}'.format('-'*40))
    print()
    return


def test_wheatstone_restore_word():
    print('{}'.format('-'*40))
    print("Start of Wheatstone restore word Testing")
    print()
    
    dict_list = dictionary_to_list('engmix.txt')
    w = Wheatstone()
    print(w)
    words = ['part','lesxon','conxection','vxindovx','VVidovv','vxorried','shallovx',
             'rAx','the-boxk-xexping','ox','fox']
    for i in range(len(words)):
        print('{:10s} --> {}'.format(words[i],w.restore_word(words[i],dict_list)))
    print()
    
    print('End of Wheatstone restore word Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_wheatstone_restore_text():
    print('{}'.format('-'*40))
    print("Start of Wheatstone restore text Testing")
    print()
    
    w = Wheatstone()
    w.set_pad('z')
    print(w)
    print()
    
    texts = ['A conscious choicez','Big lesxon','Open the vxindovx','smoxth Fexling',
             'Do not break vvindovv glasx','Do you speak xorean?z','look out xhere',
             'look out xhere. There are xelsz']
    for i in range(len(texts)):
        print('{:10s} --> {}'.format(texts[i],w.restore_plaintext(texts[i])))
    print()
    
    print('End of Wheatstone restore text Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_encrypt_decrypt():
    print('{}'.format('-'*40))
    print("Start of Wheatstone encrypt/decrypt Testing")
    print()
    
    w = Wheatstone((5,49,'BL'))
    w.set_pad('Q')
    print(w)
    print()
    
    plaintext1 = file_to_text('plaintext1.txt')
    print('plaintext =')
    print(plaintext1)
    print()
    
    ciphertext1 = w.encrypt(plaintext1)
    print('ciphertext = ')
    print(ciphertext1)
    print()
    
    plaintext2 = w.decrypt(ciphertext1)
    print('plaintext = ')
    print(plaintext2)
    print()
    
    print('End of Wheatstone restore text Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_crytanalyze():
    print('{}'.format('-'*40))
    print("Start of Wheatstone cryptanalyze Testing")
    print()
    
    print('Case 1:')
    ciphertext1 = file_to_text('ciphertext1.txt') #key should be (7,49,BL)
    key,plaintext = Wheatstone.cryptanalyze(ciphertext1, [7,49,None])
    print(key)
    print(plaintext[:90])
    print()
    
    print('Case 2:')
    ciphertext2 = file_to_text('ciphertext2.txt') #key should be (8, 25, TR)
    key,plaintext = Wheatstone.cryptanalyze(ciphertext2, [None,25,'TR'])
    print(key)
    print(plaintext[:90])
    print()
    
    print('Case 3:')
    ciphertext3 = file_to_text('ciphertext3.txt') #key should be (3, 49, BR)
    key,plaintext = Wheatstone.cryptanalyze(ciphertext3, [3,None,'BR'])
    print(key)
    print(plaintext[:90])
    print()
    
    print('End of Wheatstone cryptanalyze Testing')
    print('{}'.format('-'*40))
    print()
    return

# test_wheatstone_key()
# test_wheatstone_basics()
# test_wheatstone_base()
# test_wheatstone_table()
# test_wheatstone_plaintext_preprocessing()
# test_encrypt1()
# test_encrypt2()
# test_wheatstone_restore_word()
# test_wheatstone_restore_text()
# test_decrypt1()
# test_decrypt2()
# test_encrypt_decrypt()
test_crytanalyze()