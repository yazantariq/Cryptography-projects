import utilities
import math
import time
#------------------------
# Cryptography (Winter 2023)
# Assignment 2: Substitution Ciphers
#------------------------

#------------------------
# Student Name: yazan tariq abugazah
# Student ID: 20200906
#------------------------

class Wheatstone:

    DEFAULT_KEY = (0,25,'BR')
    CORNERS = ['BR','BL','TR','TL']
    BASE = """abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ0123456789!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""
    DICT_FILE = 'engmix.txt'

    def __init__(self,key=DEFAULT_KEY,pad='q'):
        self.__key = key
        self.__pad = pad
        pass

    def get_base(self):
        start, last, corner = self.__key
        return self.BASE[start:start + last]

    def set_key(self,key):
        if not self.valid_key(key):
            self.__key = self.DEFAULT_KEY
            return False
        self.__key = key
        return True

    def set_pad(self,pad):
        base = self.get_base()
        pad = str(pad)
        if len(pad) != 1 or pad not in base:
            self.__pad = base[-1]
            return False
        else:
            self.__pad = pad
            return True

    def get_key(self):

        return self.__key

    def get_pad(self):

        return self.__pad

    @staticmethod
    def valid_key(key):

        if not type(key) == tuple or len(key) != 3:
            return False
        start, last, corner = key
        if not type(start) == int or not type(last) == int or not type(corner) == str:
            return False
        if start < 0 or start >= len(Wheatstone.BASE):
            return False
        if last < 0 or last not in [4, 9, 16, 25, 36, 49, 64, 81]:
            return False
        if corner not in Wheatstone.CORNERS:
            return False
        if start + last > len(Wheatstone.BASE):
            return False
        return True

    def get_table(self):
        start, last, corner = self.__key
        base = self.get_base()
        unused_chars = self.get_unused_chars()
        x = math.sqrt(self.__key[1])
        y = int(x)
        table = [[''] * y for _ in range(y)]
        i = 0
        for row in range(y):
            for col in range(y):
                if i < len(base):
                    table[row][col] = base[i]

                else:
                    table[row][col] = unused_chars[i - len(base)]
                i += 1
            if row % 2 == 1:
                    table[row].reverse()

        if corner == 'TL':
            pass
        elif corner == 'TR':
            table = [row[::-1] for row in table]
        elif corner == 'BL':
            table = table[::-1]
        elif corner == 'BR':
            table = [row[::-1] for row in table[::-1]]

        if start > 0:
            table = table[start:] + table[:start]
        if last > 0:
            table = [row[-last:] + row[:-last] for row in table]

        return table

    def print_table(self):

        table = self.get_table()
        for row in table:
            print(' '.join(row), '')

    def __str__(self):
        table = self.get_table()
        table_str = ''
        for i, row in enumerate(table):
            if i == len(table) - 1:
                table_str += ' '.join(str(x) for x in row) + '\n'
            else:
                table_str += ' '.join(str(x) for x in row) + ' \n'
        return f"Wheatstone Playfair Cipher:key = {self.__key}, pad = {self.__pad}\n{table_str}"

    def get_unused_chars(self):

        base = self.get_base()
        unused_chars = []
        for i in self.BASE:
            if i not in base:
                unused_chars.append(i)
        unused_chars.extend([' ', '\n', '\t'])
        return unused_chars

    def preprocess_plaintext(self,plaintext):
        base = self.get_base()
        plaintext = plaintext.replace('w', 'vv')
        plaintext = plaintext.replace('W', 'VV')

        pos1 = []
        for i in plaintext:
            if i not in base:
                pos = utilities.get_positions(plaintext, i)
                pos1.append(pos)
                plaintext = utilities.clean_text(plaintext, i)

        if len(plaintext) % 2 == 1:
            plaintext += self.__pad

        plaintext = utilities.text_to_blocks(plaintext, 2)
        for i in range(len(plaintext)):
            block = plaintext[i]
            if len(block) != 2:
                continue
            if block[0] == block[1]:
                if block[0].isupper():
                    plaintext[i] = block[0] + 'X'
                else:
                    plaintext[i] = block[0] + 'x'

        plaintext = ''.join(plaintext)

        for pos in pos1[::-1]:
            plaintext = utilities.insert_positions(plaintext, pos)

        return plaintext

    def encrypt(self,plaintext):
        table = self.get_table()
        base = self.get_base()
        key = self.get_key()
        eq1 = math.sqrt(key[1])
        size = int(eq1)

        plaintext = self.preprocess_plaintext(plaintext)

        pos1 = []
        for i in plaintext:
            if i not in base:
                pos = utilities.get_positions(plaintext, i)
                pos1.append(pos)
                plaintext = utilities.clean_text(plaintext, i)

        ciphertext = ""
        for i in range(0, len(plaintext), 2):
            x = plaintext[i]
            y = plaintext[i + 1]

            # find position of x and y in the table
            row1, col1 = utilities.index_2d(table, x)
            row2, col2 = utilities.index_2d(table, y)

            # swap rows if x and y are in the same row
            if row1 == row2:
                col1 = (col1 + 1) % size
                col2 = (col2 + 1) % size
                ciphertext += table[row1][col1] + table[row2][col2]
            # swap columns if x and y are in the same column
            elif col1 == col2:
                row1 = (row1 + 1) % size
                row2 = (row2 + 1) % size
                ciphertext += table[row1][col1] + table[row2][col2]
            # swap x and y diagonally
            else:
                temp = col1
                col1 = col2
                col2 = temp
                ciphertext += table[row1][col1] + table[row2][col2]
        for pos in pos1[::-1]:
            ciphertext = utilities.insert_positions(ciphertext, pos)

        return ciphertext

    def restore_word(self, word, dict_list):
        base = self.get_base()
        if len(word) < 2:
            return word

        elif utilities.is_plaintext(word, utilities.dictionary_to_list('engmix.txt')):
            return word
        else:
            # Find positions of characters not in the base
            pos1 = []
            for j in word:
                if j not in base:
                    pos = [[j, i] for i, char in enumerate(word) if char == j]
                    pos1.extend(pos)
                    word = ''.join([char for char in word if char != j])

            restored_word = ""
            block_size = 2
            # Split the word into blocks of size 2
            blocks = [word[i:i + block_size] for i in range(0, len(word), block_size)]

            for block in blocks:
                if len(block) == 2:
                    if block[1] == 'x' or block[1] == 'X':
                        restored_word += block[0] * 2
                    elif block == 'vv':
                        restored_word += 'w'
                    elif block == 'VV':
                        restored_word += 'W'
                    else:
                        restored_word += block
                else:
                    restored_word += block

            # Reverse positions list and insert characters back into restored_word
            for pos in pos1[::-1]:
                if pos[1] <= len(restored_word):
                    restored_word = restored_word[:pos[1]] + pos[0] + restored_word[pos[1]:]
                else:
                    restored_word += pos[0]

            restored_word = restored_word.replace("vv", "w").replace("VV", "W")

        return restored_word

    def restore_plaintext(self,text):
        text = self.restore_word(text, 'engmix')
        text = text.rstrip(self.__pad)
        return text

    def decrypt(self,ciphertext):

        table = self.get_table()
        base = self.get_base()
        key = self.get_key()
        eq1 = math.sqrt(key[1])
        size = int(eq1)

        pos1 = []
        for i in ciphertext:
            if i not in base:
                pos = utilities.get_positions(ciphertext, i)
                pos1.append(pos)
                ciphertext = utilities.clean_text(ciphertext, i)

        plaintext = ""
        for i in range(0, len(ciphertext), 2):
            if i + 1 < len(ciphertext):
                x = ciphertext[i]
                y = ciphertext[i + 1]

                # find position of x and y in the table
                row1, col1 = utilities.index_2d(table, x)
                row2, col2 = utilities.index_2d(table, y)

                # reverse diagonal swap
                if row1 != row2 and col1 != col2:
                    plaintext += table[row1][col2] + table[row2][col1]
                # reverse row swap
                elif row1 == row2:
                    col1 = (col1 - 1) % size
                    col2 = (col2 - 1) % size
                    plaintext += table[row1][col1] + table[row2][col2]
                # reverse column swap
                else:
                    row1 = (row1 - 1) % size
                    row2 = (row2 - 1) % size
                    plaintext += table[row1][col1] + table[row2][col2]
            else :
                plaintext += ciphertext[i]

        for pos in pos1[::-1]:
            plaintext = utilities.insert_positions(plaintext, pos)

        plaintext = self.restore_plaintext(plaintext)

        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext,args=[None,None,None]):
        w = Wheatstone()
        start, size, corner = args
        start_time = time.time()
        if start is None:
            for i in range(0, len(w.BASE)-size):
                key = (i, size, corner)
                w.set_key(key)
                plaintext = w.decrypt(ciphertext)
                dictlist = utilities.dictionary_to_list('engmix.txt')
                if utilities.is_plaintext(plaintext, dictlist, 0.9):
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    print("Elapsed time: {:.2f} seconds".format(elapsed_time))
                    return key, plaintext
        if size is None:
            for i in range(2, 10):
                key = (start, i ** 2, corner)
                w.set_key(key)
                plaintext = w.decrypt(ciphertext)
                dictlist = utilities.dictionary_to_list('engmix.txt')
                if utilities.is_plaintext(plaintext, dictlist, 0.9):
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    print("Elapsed time: {:.2f} seconds".format(elapsed_time))
                    return key, plaintext
        if corner is None:
            a=['BL','BR','TR','TL']
            for i in a:
                key = (start,size, i)
                w.set_key(key)
                plaintext = w.decrypt(ciphertext)
                dictlist = utilities.dictionary_to_list('engmix.txt')
                if utilities.is_plaintext(plaintext, dictlist, 0.9):
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    print("Elapsed time: {:.2f} seconds".format(elapsed_time))
                    return key, plaintext


