from A2 import Wheatstone
from utilities import dictionary_to_list, file_to_text

def test_wheatstone_key(max_grade):
    grade = 0
    answers = [False,False,False,False,False,False,False,False,False,
               True,True,True,True]
    cases = [[0,25,'BR'],(0,25),('a',25,'BR'),(-2,25,'BR'),(100,25,'BR'),
             (0,'a','BR'),(2,25,'BT'),(21,81,'TR'),(80,25,'TR'),
             (0,9,'BR'),(1,81,'TR'),(2,36,'BL'),(80,9,'TL')]
    try:
        for i in range(len(cases)):
            key = cases[i]
            result = Wheatstone.valid_key(key)
            if result == answers[i]:
                grade += max_grade/len(cases)
    except:
        print('Exception in Wheatstone valid_key')
    return grade

def test_wheatstone_basics(max_grade):
    grade = 0
    
    #default constructor 8%
    try:
        w = Wheatstone()
        result = w.get_key()
        if result == (0, 25, 'BR'):
            grade += max_grade*0.04
        if w.get_base() == 'abcdefghijklmnopqrstuvxyz':
            grade += max_grade*0.04
    except:
        print('Exception in Wheatstone basics')
    
    #set_key = 23%
    #get_key = 23%
    keys = [(0,9,'BR'),(14,64,'BL'),(21,81,'TR')]
    answers1 = [True,True,False]
    answers2 = [(0, 9, 'BR'),(14, 64, 'BL'),(0, 25, 'BR')]
    try:
        for i in range(len(keys)):
            k = keys[i]
            result1 = w.set_key(k)
            if result1 == answers1[i]:
                grade += max_grade*0.23/len(keys)
            result2 = w.get_key()
            if result2 == answers2[i]:
                grade += max_grade*0.23/len(keys)
    except:
        print('Exception in Wheatstone.set_key or get_key')

    #set_pad = 23%
    #get_pad = 23%
    pads = ['','Z','x','xx',3]
    answers1 = [False,False,True,False,False]
    answers2 = ['z','z','x','z','z']
    try:
        for i in range(len(pads)):
            result1 = w.set_pad(pads[i])
            if result1 == answers1[i]:
                grade += max_grade*0.23/len(pads)
            result2 = w.get_pad()
            if result2 == answers2[i]:
                grade += max_grade*0.23/len(pads)
    except:
        print('Exception in Wheatstone.set_pad or get_pad')
       
    return grade

def test_wheatstone_base(max_grade):
    grade = 0
    keys = [(16,49,'BR'),(14,64,'BL'),(6,81,'TR')]
    answers1 = ["""qrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ0123456789!"#$%""",
                """opqrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ0123456789!"#$%&'()*+,-./:;<""",
                """ghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ0123456789!"#$%&'()*+,-./:;<=>?@[\]^_"""]
    answers2 = [['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', ' ', '\n', '\t'],
                ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', ' ', '\n', '\t'],
                ['a', 'b', 'c', 'd', 'e', 'f', '`', '{', '|', '}', '~', ' ', '\n', '\t']]
    try:
        w = Wheatstone()
        for i in range(len(keys)):
            w.set_key(keys[i])
            if w.get_base() == answers1[i]:
                grade += max_grade/(2*len(keys))
            if w.get_unused_chars() == answers2[i]:
                grade += max_grade/(2*len(keys))
    except:
        print('Exception in Wheatstone get_base or get_unused_chars')            
    return grade

def test_wheatstone_table(max_grade):
    grade = 0

    cases = [(0,25,'TL'),(0,25,'TR'),(0,25,'BL'),(0,25,'BR'),
             (14,36,'TL'),(14,36,'TR'),(14,36,'BL'),(14,36,'BR')]


    #get_table 50% 
    answers = [[['a', 'b', 'c', 'd', 'e'], ['j', 'i', 'h', 'g', 'f'], ['k', 'l', 'm', 'n', 'o'], ['t', 's', 'r', 'q', 'p'], ['u', 'v', 'x', 'y', 'z']],
               [['e', 'd', 'c', 'b', 'a'], ['f', 'g', 'h', 'i', 'j'], ['o', 'n', 'm', 'l', 'k'], ['p', 'q', 'r', 's', 't'], ['z', 'y', 'x', 'v', 'u']],
               [['u', 'v', 'x', 'y', 'z'], ['t', 's', 'r', 'q', 'p'], ['k', 'l', 'm', 'n', 'o'], ['j', 'i', 'h', 'g', 'f'], ['a', 'b', 'c', 'd', 'e']],
               [['z', 'y', 'x', 'v', 'u'], ['p', 'q', 'r', 's', 't'], ['o', 'n', 'm', 'l', 'k'], ['f', 'g', 'h', 'i', 'j'], ['e', 'd', 'c', 'b', 'a']],
               [['o', 'p', 'q', 'r', 's', 't'], ['A', 'z', 'y', 'x', 'v', 'u'], ['B', 'C', 'D', 'E', 'F', 'G'], ['M', 'L', 'K', 'J', 'I', 'H'], ['N', 'O', 'P', 'Q', 'R', 'S'], ['Z', 'Y', 'X', 'V', 'U', 'T']],
               [['t', 's', 'r', 'q', 'p', 'o'], ['u', 'v', 'x', 'y', 'z', 'A'], ['G', 'F', 'E', 'D', 'C', 'B'], ['H', 'I', 'J', 'K', 'L', 'M'], ['S', 'R', 'Q', 'P', 'O', 'N'], ['T', 'U', 'V', 'X', 'Y', 'Z']],
               [['Z', 'Y', 'X', 'V', 'U', 'T'], ['N', 'O', 'P', 'Q', 'R', 'S'], ['M', 'L', 'K', 'J', 'I', 'H'], ['B', 'C', 'D', 'E', 'F', 'G'], ['A', 'z', 'y', 'x', 'v', 'u'], ['o', 'p', 'q', 'r', 's', 't']],
               [['T', 'U', 'V', 'X', 'Y', 'Z'], ['S', 'R', 'Q', 'P', 'O', 'N'], ['H', 'I', 'J', 'K', 'L', 'M'], ['G', 'F', 'E', 'D', 'C', 'B'], ['u', 'v', 'x', 'y', 'z', 'A'], ['t', 's', 'r', 'q', 'p', 'o']]]
    try:
        w = Wheatstone()
        for i in range(len(cases)):
            w.set_key(cases[i])
            if w.get_table() == answers[i]:
                grade += max_grade/len(cases)
    except:
        print('Exception in Wheatstone get_table') 
        
    return grade

def test_encrypt1(max_grade):
    grade = 0
    try:
        w = Wheatstone()
        w.set_pad('z')
        
        plaintexts = ['gi','qr','nk','rh','sl','pe','gc','mq','oi','vp','az',
                      'LH','32','zF','Q7','CJ','6-','EM','LZ',',p']
        answers = ['hj','rs','mo','mc','li','oz','hd','nr','lf','zs','eu',
                   'KG','21','Ay','2)','JS','*v','zH','I2','=x']
        
        for i in range(len(plaintexts)):
            if i == 11:
                w.set_key((15,64,'TR'))
            p = plaintexts[i]
            try:
                result = w.encrypt(p)
                if result == answers[i]:
                    grade += max_grade/len(plaintexts)
            except:
                print('Exception in Wheatstone encrypt1')
    except:
        print('Exception in Wheatstone encrypt1')     
    return grade

def test_plaintext_preprocessing(max_grade):
    grade = 0

    plaintexts = ['part','light','lesson','door','floor','c','window','Widow','worried',
                  'shallow','hallow','Ramadan','March?','February?','are you happy?',
                  'Are you happy?','Wow!! That is wonderful!','bad work','volvo','cows',
                  'the-book-keeping']
    answers = ['part','lightz','lesxon','door','floxrz','cz','vxindovx','VVidovvz',
               'vxorried','shallovx','halxovvz','Ramadan','March?','February?z',
               'are you hapxy?z','Are you happy?','VVovv!! That is vxonderful!',
               'bad vvork','volvoz','covxsz','the-boxk-xexping']
        
    try:
        w = Wheatstone()
        w.set_pad('z')
    
        for i in range(len(plaintexts)):
            result = w.preprocess_plaintext(plaintexts[i])
            if result == answers[i]:
                grade += max_grade*0.5/len(plaintexts)
        
        answers = ['']
        w.set_key((15,49,'TR'))
        w.set_pad('#')
        answers = ['part#','light#','lesxon','door#','floor#','c','vxindovx','VXidovx',
                  'vxorxied','shallovv#','hallovx','Ramadan#','March?','February?#','are you happy?',
                  'Are you hapxy?#','VXovx!x That is vvonderful!','bad vxork#','volxo','covxs#','the-book-keeping']
        for i in range(len(plaintexts)):
            result = w.preprocess_plaintext(plaintexts[i])
            if result == answers[i]:
                grade += max_grade*0.5/len(plaintexts)
    except:
        print('Exception in plaintext preprocessing')
    return grade

def test_encrypt2(max_grade):
    grade = 0
    plaintexts = ['rr','c','m-m','aabb','abba','concessions', 'Best Match',
                  'Introduction to Cryptography','GO OUT OF YOUR COMFORT ZONE',
                  'Why did you get married too late?','SMILING IS A FORM OF CHARITY']
    answers = ['mr','ex','h-r','cucv','eaae','emmdbplbnmpv','Bbpk Murafx',
                   'Ikqpmayarflk qm Cpzqpkhqetgx','HP PVV QJ TPVQ DPNHQQS VLRI',
                   'UVhx djd Djt ges raBvmed pki mave?2',
                   'YRKNNXF HV D HQLN QH AFDOFXZ1']
    try:  
        w = Wheatstone()
        w.set_pad('z')
        for i in range(len(plaintexts)):
            if i == 8:
                w.set_key((8,49,'TL'))
                w.set_pad('0')
            p = plaintexts[i]
            try:
                result = w.encrypt(p)
                if result == answers[i]:
                    grade += max_grade/len(plaintexts)
            except:
                print('Exception in Wheatstone encrypt2')
    except:
        print('Exception in Wheatstone encrypt2')         
    return grade

def test_restore_word(max_grade):
    grade = 0
    words = ['part','lesxon','conxection','vxindovx','VVidovv','vxorried','shallovx',
             'rAx','the-boxk-xexping','ox','fox']
    answers = ['part','lesson','connection','window','Widow','worried','shallow','rAr',
               'the-book-keeping','ox','fox']

    try:
        dict_list = dictionary_to_list('engmix.txt')
        w = Wheatstone()
        for i in range(len(words)):
            try:
                result = w.restore_word(words[i],dict_list)
                if result == answers[i]:
                    grade += max_grade/len(words)
            except:
                print('Exception in Wheatstone restore_word')
    except:
        print('Exception in Wheatstone restore_word')
    return grade

def test_decrypt1(max_grade):
    grade = 0    
    
    answers = ['gi','qr','nk','rh','sl','pe','gc','mq','oi','vp','a',
                  'LH','32','zF','Q7','CJ','6-','EM','LZ',',p']
    ciphertexts = ['hj','rs','mo','mc','li','oz','hd','nr','lf','zs','eu',
               'KG','21','Ay','2)','JS','*v','zH','I2','=x']
    
    try:
        w = Wheatstone()
        w.set_pad('z')
        for i in range(len(ciphertexts)):
            if i == 11:
                w.set_key((15,64,'TR'))
            c = ciphertexts[i]
            try:
                result = w.decrypt(c).strip()
                if result == answers[i]:
                    grade += max_grade/len(ciphertexts)
            except:
                print('Exception in Wheatstone decrypt1')
    except:
        print('Exception in Wheatstone decrypt1')     
    return grade
       
def test_decrypt2(max_grade):
    grade = 0    
    
    ciphertexts = ['mr','ex','h-r','cucv','eaae','emmdbplbnmpv','Bbpk Murafx',
                   'Ikqpmayarflk qm Cpzqpkhqetgx','HP PVV QJ TPVQ DPNHQQS VLRI',
                   'UVhx djd Djt ges raBvmed pki mave?2',
                   'YRKNNXF HV D HQLN QH AFDOFXZ1']
    answers = ['rr','c','m-m','aabb','abba','concessions', 'Best Match',
                  'Introduction to Cryptography','GO OUT OF YOUR COMFORT ZONE',
                  'Why did you get married too late?','SMILING IS A FORM OF CHARITY']
    try:
        w = Wheatstone()
        w.set_pad('z')
        for i in range(len(ciphertexts)):
            if i == 8:
                w.set_key((8,49,'TL'))
                w.set_pad('0')
            c = ciphertexts[i]
            try:
                result = w.decrypt(c).strip()
                if result == answers[i]:
                    grade += max_grade/len(ciphertexts)
            except:
                print('Exception in Wheatstone decrypt2')
    except:
        print('Exception in Wheatstone decrypt2')     
    return grade

def test_restore_text(max_grade):
    grade = 0
    
    texts = ['A conscious choicez','Big lesxon','Open the vxindovx','smoxth Fexling',
             'Do not break vvindovv glasx','Do you speak xorean?z','look out xhere',
             'look out xhere. There are xelsz']
    answers = ['A conscious choice','Big lesson','Open the window','smooth Feeling',
               'Do not break window glass','Do you speak korean?','look out there',
               'look out there. There are eels']
    try:
        w = Wheatstone()
        w.set_pad('z')
        for i in range(len(texts)):
            try:
                result = w.restore_plaintext(texts[i]).strip()
                if result == answers[i]:
                    grade += max_grade/len(texts)
            except:
                print('Exception in Wheatstone restore_plaintext')
    except:
        print('Exception in Wheatstone restore_plaintext')        
    return grade

def test_encrypt_decrypt(max_grade):
    grade = 0
    
    try:
        w = Wheatstone((5,49,'BL'))
        w.set_pad('Q')
        
        plaintext1 = file_to_text('plaintext1.txt')
        ciphertext1 = w.encrypt(plaintext1)
        answer1 = 'RAvfnm Xeasrgeo a dtmasfc xxoe otfses amd avunsaxfc peAnqA oarakesems.\nHs fxronsur sAgxfmie oqrjqasplrk oaqadjhsr, \nkpcgAdkpj rbfecy-nqkepxed, fsoesauhxe, gtsczjpmak amd oqncedrgak, \namd faq a gamke ard cnsoqekeqpfte qzasdamd ggbpaou.'
        if ciphertext1 == answer1:
            grade += max_grade/2
        plaintext2 = w.decrypt(ciphertext1)
        answer2 = 'Python features a dynamic type system and automatic mexory management.\nIt supports multiple programming paradigms, \nincluding object-oriented, imperative, functional and procedural, \nand has a large and comprehensive standard library.'
        if plaintext2.strip() == answer2.strip() or plaintext2.strip() == plaintext1.strip():
            grade += max_grade/2
    except:
        print('Exception in encrypt-decrypt')
    return grade

def test_crytanalyze(max_grade):
    grade = 0
    try:   
        ciphertext1 = file_to_text('ciphertext1.txt') #key should be (7,49,BL)
        key,plaintext = Wheatstone.cryptanalyze(ciphertext1, [7,49,None])
        answer_plain = 'In cryptography, the one-time pad (OTP) is an encryption technique that cannot be cracked,'
        answer_key1 = (7, 49, 'BL')
        if plaintext[:90] == answer_plain:
            grade += max_grade/6
        if key == answer_key1:
            grade += max_grade/6
        
        ciphertext2 = file_to_text('ciphertext2.txt') #key should be (8, 25, TR)
        key,plaintext = Wheatstone.cryptanalyze(ciphertext2, [None,25,'TR'])
        answer_key2 = (8, 25, 'TR')
        if plaintext[:90] == answer_plain:
            grade += max_grade/6
        if key == answer_key2:
            grade += max_grade/6
        
        ciphertext3 = file_to_text('ciphertext3.txt') #key should be (3, 49, BR)
        key,plaintext = Wheatstone.cryptanalyze(ciphertext3, [3,None,'BR'])
        answer_key3 = (3, 49, 'BR')
        if plaintext[:90] == answer_plain:
            grade += max_grade/6
        if key == answer_key3:
            grade += max_grade/6
    except:
        print('Exception in Cryptanalysis')
    
    return grade

def grader():    
    grades = [0 for _ in range(13)]
    scores = [6,8,6,6,10,8,8,8,8,8,8,6,10]
    grades[0] = test_wheatstone_key(scores[0])
    grades[1] = test_wheatstone_basics(scores[1])
    grades[2] = test_wheatstone_base(scores[2])
    grades[3] = test_wheatstone_table(scores[3])
    grades[4] = test_plaintext_preprocessing(scores[4])
    grades[5] = test_encrypt1(scores[5])
    grades[6] = test_encrypt2(scores[6])
    grades[7] = test_restore_word(scores[7])
    grades[8] = test_restore_text(scores[8])
    grades[9] = test_decrypt1(scores[9])
    grades[10] = test_decrypt2(scores[10])
    grades[11] = test_encrypt_decrypt(scores[11])
    grades[12] = test_crytanalyze(scores[12])
    total = sum(grades)

    print('{}'.format('-'*40))
    print("Start of Assignment 2 Grader")
    print()
    print('Wheatstone Cipher:')
    print('  valid_key            = {:.2f}/{}'.format(grades[0],scores[0]))
    print('  basics               = {:.2f}/{}'.format(grades[1],scores[1]))
    print('  base                 = {:.2f}/{}'.format(grades[2],scores[2]))
    print('  table                = {:.2f}/{}'.format(grades[3],scores[3]))
    print('  plain preprocessing  = {:.2f}/{}'.format(grades[4],scores[4]))
    print('  encrypt1             = {:.2f}/{}'.format(grades[5],scores[5]))
    print('  encrypt2             = {:.2f}/{}'.format(grades[6],scores[6]))
    print('  restore_word         = {:.2f}/{}'.format(grades[7],scores[7]))
    print('  restore_text         = {:.2f}/{}'.format(grades[8],scores[8]))
    print('  decrypt1             = {:.2f}/{}'.format(grades[9],scores[9]))
    print('  decrypt2             = {:.2f}/{}'.format(grades[10],scores[10]))
    print('  encrypt-decrypt      = {:.2f}/{}'.format(grades[11],scores[11]))
    print('  cryptanalysis        = {:.2f}/{}'.format(grades[12],scores[12]))
    
    print()
    print('Total = {:.2f}/{}'.format(total,sum(scores)))
    print()
    
    print('End of Grader Testing')
    print('{}'.format('-'*40))
    return 
grader()