def get_table(base):
    size = 5
    table = [[''] * size for _ in range(size)]

    directions = [(0, 1), (-1, 0), (0, -1), (1, 0)]  # right, up, left, down
    direction_index = 0
    x, y = size - 1, size - 1  # starting from bottom right corner
    base_index = 0

    for step in range(size * size):
        if 0 <= x < size and 0 <= y < size:
            table[x][y] = base[base_index]
            base_index += 1

        dx, dy = directions[direction_index]
        nx, ny = x + dx, y + dy

        if 0 <= nx < size and 0 <= ny < size and table[nx][ny] == '':
            x, y = nx, ny
        else:
            direction_index = (direction_index + 1) % 4
            dx, dy = directions[direction_index]
            x, y = x + dx, y + dy

    return table

def get_table_str(table):
    table_str = ''
    for row in table:
        table_str += ' '.join(row) + '\n'
    return table_str

# Example usage:
print(get_table())
get_base = "amzingbcdefhjklopqrstuvxy"
table = get_table(get_base)
print(get_table_str(table))

