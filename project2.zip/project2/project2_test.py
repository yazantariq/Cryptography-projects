import utilities
from A3 import Cryptanalysis, Shift, Vigenere

def test_IOC():
    print('{}'.format('-'*40))
    print("Start of index_of_coincidence Testing")
    print()

    files = ['plaintext1.txt', 'plaintext2.txt','ciphertext1.txt', 'random_text.txt','lorem ipsum.txt','empty_file.txt']
    for file in files:
        text = utilities.file_to_text(file)
        print('IOC({}) = \t{:.4f}'.format(file,Cryptanalysis.index_of_coincidence(text, None)))
    print()
    
    print('End of index_of_coincidence Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_chi_squared():
    print('{}'.format('-'*40))
    print("Start of Chi Squared Testing")
    print()

    files = ['plaintext1.txt', 'plaintext2.txt','ciphertext1.txt', 'random_text.txt','lorem ipsum.txt','empty_file.txt']
    for file in files:
        text = utilities.file_to_text(file)
        print('chi_squared({}) = \t{:.3f}'.format(file,Cryptanalysis.chi_squared(text)))
    
    print()
    print('End of Chi Squared Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_freidman():
    print('{}'.format('-'*40))
    print("Start of friedman Testing")
    print()

    for i in range(5):
        cipher_file = 'ciphertext'+str(i+1)+'.txt'
        ciphertext = utilities.file_to_text(cipher_file)
        friedman = Cryptanalysis.friedman(ciphertext)
        print('friedman({}) = {}'.format(cipher_file,friedman))
    
    print()
    print('End of friedman Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_cipher_shifting():
    print('{}'.format('-'*40))
    print("Start of cipher shifting Testing")
    print()

    for i in range(5):
        cipher_file = 'ciphertext'+str(i+1)+'.txt'
        ciphertext = utilities.file_to_text(cipher_file)
        c_shift = Cryptanalysis.cipher_shifting(ciphertext)
        print('cipher_shifting({}) = {}'.format(cipher_file, c_shift))
    
    print()
    print('End of cipher_shifting Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_shift_basics():
    print('{}'.format('-'*40))
    print("Start of Shift Basic Testing")
    print()

    print('Creating a Shift cipher object using default constructor:')
    shift = Shift()
    print(shift)
    print()
    
    print('Testing Shift.valid_key:')
    keys = [[4,6,29],(3,15),(3,'15',24),(5.0,15,24), (-5,-4,23), (-5,4,-23),
            (11,23,4),(9,2,94), (13,35,93),(-6,0,19)]
    for k in keys:
        print('{} --> {}'.format(k,Shift.valid_key(k)))
    print()
    
    print('Testing basic functions:')
    keys = [(15,35,62),(-15,12,88), (-16,44,13)]
    for k in keys:
        print('shift.set_key({}) = '.format(k),end='')
        print(shift.set_key(k))
        print('shift.get_key() = {}'.format(shift.get_key()))
        print('shift.get_base() = {}'.format(shift.get_base()))
        print(shift)
        print()
    
    print('End of Shift Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_shift():
    print('{}'.format('-'*40))
    print("Start of Shift Cipher Testing")
    print()
    
    shift = Shift()
    plaintext = utilities.file_to_text('plaintext1.txt')
    keys = [(14,2,43),(-15,12,88),(6,30,93)]
    for key in keys:
        shift.set_key(key)
        print(shift)
        print('plaintext = {}'.format(plaintext[101:181]))
        ciphertext = shift.encrypt(plaintext)
        print('ciphertext= {}'.format(ciphertext[101:181]))
        plaintext2 = shift.decrypt(ciphertext)
        print('plaintext2= {}'.format(plaintext2[101:181]))
        if plaintext == plaintext2:
            print('Validated')
        else:
            print('Validation Failed')
        print()
    
    print('End of Shift Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_shift_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Shift Cryptanalysis Testing")
    print()
    
    cases = [['ciphertext6.txt','abcdefghijklmnopqrstuvwxyz01234', 8, 31],
             ['ciphertext6.txt','abcdefghijklmnopqrstuvwxyz01234', -1, -1],
             ['ciphertext6.txt','',8,31],
             ['ciphertext7.txt','',-1,22]]
    
    for c in cases:
        ciphertext = utilities.file_to_text(c[0])
        key,plaintext = Shift.cryptanalyze(ciphertext, c[1:])
        print('Cryptanlaysis of {}'.format(c[0]))
        print('key = {}'.format(key))
        print('plaintext = {}'.format(plaintext[:99]))
        print()
        
    print('End of Shift Cryptanalysis Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_vigenere_basics():
    print('{}'.format('-'*40))
    print("Start of vigenere Basic Testing")
    print()

    print('Creating a Vigenere cipher object using default constructor:')
    vigenere = Vigenere()
    print(vigenere)
    print()
    
    print('Testing vigenere.valid_key:')
    keys = ['r', 'B', '$', 'ab', 'Cd' , 'a$a', '?_!']
    for k in keys:
        print('{} --> {}'.format(k,vigenere.valid_key(k)))
    print()
    
    print('Testing get_base:')
    base = vigenere.get_square()
    for b in base:
        print(b)
    print()
    
    print('Testing set_key, get_key, __str__:')
    keys = ['Germany', 'BANGLADESH', 'Central Africa', '3dollars50cents', '$3.50', '5p5']
    for k in keys:
        print('vigenere.set_key({}) = '.format(k),end='')
        print(vigenere.set_key(k))
        print('vigenere.get_key() = {}'.format(vigenere.get_key()))
        print(vigenere)
        print()
    
    print('End of vigenere Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_vigenere():
    print('{}'.format('-'*40))
    print("Start of vigenere Cipher Testing")
    print()
    
    vigenere = Vigenere()
    plaintext = utilities.file_to_text('plaintext3.txt')
    keys = ['germany', 'Bangladesh', 'Central Africa']
    for i in range(len(keys)):
        vigenere.set_key(keys[i])
        print(vigenere)
        print('plaintext = {}'.format(plaintext[101:181]))
        ciphertext = vigenere.encrypt(plaintext)
        print('ciphertext= {}'.format(ciphertext[101:181]))
        plaintext2 = vigenere.decrypt(ciphertext)
        print('plaintext2= {}'.format(plaintext2[101:181]))
        if plaintext == plaintext2:
            print('Validated')
        else:
            print('Validation Failed')
        print()
    
    print('End of vigenere Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_vigenere_key_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Vigenere key length Cryptanalysis Testing")
    print()
    
    countries = utilities.file_to_text('countries.txt').split('\n') 
    
    vigenere = Vigenere()
    
    print('------------- Key Length Using Friedman Method:')
    counter = 0
    plaintext = utilities.file_to_text('plaintext3.txt')
    for key in countries:
        vigenere.set_key(key)
        ciphertext = vigenere.encrypt(plaintext)
        friedman = Cryptanalysis.friedman(ciphertext)
        print('key = {:15s} len = {:2d} friedman = {}'.format(key,len(key),friedman),end='\t')
        if len(key) in friedman:
            print('Good')
            counter += 1
        else:
            print('Bad')
    print('Found {} out of {} keys'.format(counter,len(countries)))  
    print()
      
    print('------------- Key Length Using Cipher Shifting Method:')
    ciphertext = utilities.file_to_text('ciphertext4.txt')
    
    counter = 0
    for key in countries:
        vigenere.set_key(key)
        ciphertext = vigenere.encrypt(plaintext)
        shifting = Cryptanalysis.cipher_shifting(ciphertext)
        print('key = {:15s} len = {:2d} shifting = {}'.format(key,len(key),shifting),end='\t')
        if len(key) in shifting:
            print('Good')
            counter += 1
        else:
            print('Bad')
    print('Found {} out of {} keys'.format(counter,len(countries)))  
    print()
     
    print('------------- Key Length Using Both Methods:')
    counter = 0
    for key in countries:
        vigenere.set_key(key)
        ciphertext = vigenere.encrypt(plaintext)
        keys = Vigenere.cryptanalyze_key_length(ciphertext)
        print('key = {:15s} len = {:2d} keys = {} '.format(key,len(key),keys),end='\t')
        if len(key) in keys:
            print('Good')
            counter+=1
        else:
            print('Bad')
    print('Found {} out of {} keys'.format(counter,len(countries)))  
    print()
    
    print('End of Vigenere key length Cryptanalysis Testing')
    print('{}'.format('-'*40))
    print()
    return
    
def test_vigenere_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of vigenere Cryptanalysis Testing")
    print()
    
    countries = utilities.file_to_text('countries.txt').split('\n') 
    
    vigenere = Vigenere()
    
    plaintext = utilities.file_to_text('plaintext3.txt')
    for key in countries[:10]:
        vigenere.set_key(key)
        ciphertext = vigenere.encrypt(plaintext)
        key2,_ = vigenere.cryptanalyze(ciphertext)
        print('original key = {:15s}, found key = {:15s}'.format(key,key2,end='\t'))
    print()
        
    print('End of vigenere Cryptanalysis Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return
    

test_IOC()
test_chi_squared()
test_freidman()
test_cipher_shifting()
test_shift_basics()
test_shift()
test_shift_cryptanalysis()
test_vigenere_basics()
test_vigenere()
test_vigenere_key_cryptanalysis()
test_vigenere_cryptanalysis()
