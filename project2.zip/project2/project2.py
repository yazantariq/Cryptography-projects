#------------------------
# Cryptography (Winter 2023)
# Assignment 3: Vigenere Cipher
#------------------------

#------------------------
# Student Name: yazan tariq abugazah
# Student ID: 20200906
#------------------------

import utilities
import string
import math

class Cryptanalysis:
    """
    ----------------------------------------------------
    Description: Class That contains cryptanalysis functions
                 Mainly for Vigenere and Shift Cipher 
                     but can be used for other ciphers
    ----------------------------------------------------
    """
    @staticmethod    
    def index_of_coincidence(text,base_type = None):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   text(str)
                      base_type(str): default = None
        Return:       I (float): Index of Coincidence
        Description:  Computes and returns the index of coincidence 
                      Uses English alphabets by default, otherwise, given base_type
        Asserts:      text is a string
        ----------------------------------------------------
        """
        assert isinstance(text, str), 'invalid input'

        frequency = utilities.frequency_analysis(text, base_type)
        n = sum(frequency)
        I = sum(i * (i - 1) for i in frequency)

        if n == 0:
            return 0

        I /= n * (n - 1)

        return I

    @staticmethod
    def IOC(text):
        """
        ----------------------------------------------------
        Same as Cryptanalysis.index_of_coincidence(text)
        ----------------------------------------------------
        """
        return Cryptanalysis.index_of_coincidence(text)
    
    @staticmethod
    def friedman(ciphertext):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext(str)
        Return:       list of two key lengths [int,int]
        Description:  Uses Friedman's test to compute key length
                      returns best two candidates for key length
                        Best candidates are the floor and ceiling of the value
                          Starts with most probable key, for example: 
                          if friedman = 3.2 --> [3, 4]
                          if friedman = 4.8 --> [5,4]
                          if friedman = 6.5 --> [6, 5]
        Asserts:      ciphertext is a non-empty string
        ----------------------------------------------------
        """
        n = len(ciphertext)
        I = Cryptanalysis.index_of_coincidence(ciphertext, None)
        k = 0.0265 * n / ((0.065 - I) + n * (I - 0.0385))

        most = round(k)
        less = most - 1 if most > k else most + 1

        key_lengths = [most, less]

        return key_lengths

    @staticmethod
    def chi_squared(text,language='English'):
        """
        ----------------------------------------------------
        Parameters:   text (str)
        Return:       result (float)
        Description:  Calculates the Chi-squared statistics
                      for given text
                      Only alpha characters are considered
        Asserts:      text is a string
        ----------------------------------------------------
        """

        base_type = string.ascii_uppercase
        expected_freqs = [
                0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015,
                0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
                0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
                0.00978, 0.0236, 0.0015, 0.01974, 0.00074
            ]

        if len(text) == 0:
            return -1

        observed_freqs = [0] * len(expected_freqs)
        for c in text.upper():
            if c in base_type:
                observed_freqs[base_type.index(c)] += 1
        N = sum(observed_freqs)

        result = 0.0
        if N > 0:
            for i in range(len(expected_freqs)):
                if expected_freqs[i] == 0:
                    continue
                diff = observed_freqs[i] / N - expected_freqs[i]
                result += diff * diff / expected_freqs[i]
            result *= N
        return result

    @staticmethod
    def cipher_shifting(ciphertext, args=[20, 26]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      args (lsit):
                          max_key_length (int): default = 20
                          factor (int): default = 26
        Return:       Best two key lengths [int,int]

        Description:  Uses Cipher shifting to compute key length
                      returns best two candidates for key length
                      cipher shift factor determines how many shifts should be made
                      Cleans the text from all non-alpha characters before shifting
                      Upper and lower case characters are considered different chars

                      The returned two keys, are the ones that produced highest matches
                          if equal, start with smaller value

        Asserts:      ciphertext is a non-empty string
        ----------------------------------------------------
        """
        base = ' ' + '\n' + utilities.get_chars('nonalpha')
        ciphertext = utilities.clean_text(ciphertext, base)

        max_key_length, factor = args

        shifted_cipher = ciphertext
        matches = [0, 0]
        match_indices = [0, 0]

        for shift_num in range(1, factor):
            shifted_cipher = ' ' + shifted_cipher[:-1]
            n_matches = utilities.compare_texts(ciphertext, shifted_cipher)

            adj_shift_num = shift_num % max_key_length if shift_num > max_key_length else shift_num

            if n_matches > matches[0]:
                matches = [n_matches, matches[0]]
                match_indices = [adj_shift_num, match_indices[0]]
            elif n_matches > matches[1]:
                matches[1] = n_matches
                match_indices[1] = adj_shift_num

        return match_indices

class Shift:
    """
    ----------------------------------------------------
    Cipher name: Shift Cipher
    Key:         (int,int,int): shifts,start_index,end_index
    Type:        Shift Substitution Cipher
    Description: Generalized version of Caesar cipher
                 Uses a subset of BASE for substitution table
                 Shift base by key and then substitutes
                 Case sensitive
                 Preserves the case whenever possible
                 Uses circular left shift
    ----------------------------------------------------
    """
    BASE = utilities.get_chars('pascii')
    DEFAULT_KEY = (3,26,51) #lower case Caesar cipher
    
    def __init__(self,key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (int,int,int): 
                        #shifts, start_index, end_indx 
                        (inclusive both ends of indices)
        Description:  Shift constructor
                      sets _key
        ---------------------------------------------------
        """
        self._key = key

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Shift key
        ---------------------------------------------------
        """
        return self._key
       
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (str): non-empty string
        Return:       success: True/False
        Description:  Sets Shift cipher key to given key
                      #shifts is set to smallest value
                      if invalid key --> set to default key
        ---------------------------------------------------
        """
        shifts, start_index, end_index = key
        if shifts < 0:
            shifts = (end_index - start_index) + 1 + shifts
        if self.valid_key(key):
            self._key = (shifts, start_index, end_index)
            return True
        else:
            self._key = self.DEFAULT_KEY
            return False

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the base characters
                      base is the subset of characters from BASE
                      starting at start_index and ending with end_index
                      (inclusive both ends)
        ---------------------------------------------------
        """
        shifts, start_index, end_index = self._key
        base = self.BASE[start_index: end_index + 1]
        return base
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Shift object. Used for testing
                      output format:
                      Shift Cipher:
                      key = <key>
                      base = <base>
                      sub  = <sub>
        ---------------------------------------------------
        """
        shifts, start_index, end_index = self._key
        base = self.get_base()
        sub = utilities.shift_string(base, shifts, 'l')
        output = f"Shift Cipher:\nkey = {self._key}\nbase = {self.get_base()}\nsub  = {sub}"
        return output

    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Shift key
                      A valid key is a tuple consisting of three integers
                          shifts, start_index, end_index
                      The shifts can be any integer
                      The start and end index should be positive values
                      such that start is smaller than end and both are within BASE
        ---------------------------------------------------
        """
        if not type(key) == tuple or len(key) != 3:
            return False

        shifts, start_index, end_index = key

        if not type(shifts) == int:
            return False

        if not type(start_index) == int or not type(end_index) == int:
            return False
        if start_index < 0 or end_index < 0:
            return False

        if start_index >= len(Shift.BASE) or end_index >= len(Shift.BASE):
            return False

        if start_index >= end_index:
            return False

        return True

    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Shift Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        (shifts, start_index, end_index) = self._key
        base = self.get_base()
        sub = utilities.shift_string(base, shifts, 'l')
        ciphertext = ''
        for c in plaintext:
            plainchar = c
            if plainchar in base:
                indx = base.index(plainchar)
                cipherchar = sub[indx]
            else:
                cipherchar = plainchar
            ciphertext += cipherchar

        return ciphertext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Shift Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid ciphertext'
        (shifts, start_index, end_index) = self._key
        base = self.get_base()
        sub = utilities.shift_string(base, shifts, 'l')
        plaintext = ""
        for c in ciphertext:
            cipherChar = c
            if cipherChar in base:
                indx = sub.index(cipherChar)
                plainChar = base[indx]
            else:
                plainChar = cipherChar
            plaintext += plainChar
        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext,args=['',-1,-1]):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
                      args (list):
                            base: (str): default = ''
                            shifts: (int): default = -1
                            base_length (int): default = -1
        Return:       key,plaintext
        Description:  Cryptanalysis of Shift Cipher
                      Returns plaintext and key (shift,start_indx,end_indx)
                      Uses the Chi-square method
                      Assumes user passes a valid args list
        ---------------------------------------------------
        """
        base, shifts, base_length = args
        key = (0, 0, 0)
        plaintext = ''
        compare_chi = 1002955768

        if base != '' and shifts != -1 and base_length != -1:
            start = utilities.get_positions(Shift.BASE, base[0])[0][1]
            end = utilities.get_positions(Shift.BASE, base[-1])[0][1]
            key = (shifts, start, end)
            shift = Shift(key)
            plaintext = shift.decrypt(ciphertext)

        elif base != '' and shifts == -1:
            start = utilities.get_positions(Shift.BASE, base[0])[0][1]
            end = utilities.get_positions(Shift.BASE, base[-1])[0][1]
            shift_key_found = 0
            runs = len(base)
            for shifts in range(runs):
                key = (shifts, start, end)
                shift = Shift(key)
                plaintext = shift.decrypt(ciphertext)
                chi_squared_result = Cryptanalysis.chi_squared(plaintext, language='English')
                if chi_squared_result <= compare_chi:
                    compare_chi = chi_squared_result
                    shift_key_found = shifts
            key = (shift_key_found, start, end)
            shift = Shift(key)
            plaintext = shift.decrypt(ciphertext)

        elif base == '' and shifts != -1 and base_length != -1:
            for i in range(len(Shift.BASE)):
                start = i
                if (i + base_length < len(Shift.BASE)):
                    end = i + base_length + 1
                else:
                    break
                run = 1
                for _ in range(base_length):
                    end = i + run + 1
                    temp_key = (shifts, start, end)
                    shift = Shift(temp_key)
                    plaintext = shift.decrypt(ciphertext)
                    chi_squared_result = Cryptanalysis.chi_squared(plaintext, language='English')
                    if chi_squared_result <= compare_chi:
                        compare_chi = chi_squared_result
                        key = (shifts, start, end)
                    run += 1
            shift = Shift(key)
            plaintext = shift.decrypt(ciphertext)

        elif base == '' and shifts == -1 and base_length != -1:
            for i in range(len(Shift.BASE)):
                start = i
                if (i + base_length < len(Shift.BASE)):
                    end = i + base_length + 1
                else:
                    break
                run = 1
                for _ in range(base_length):
                    end = i + run + 1
                    for shifts in range(base_length):
                        temp_key = (shifts, start, end)
                        shift = Shift(temp_key)
                        plaintext = shift.decrypt(ciphertext)
                        chi_squared_result = Cryptanalysis.chi_squared(plaintext, language='English')
                        if chi_squared_result <= compare_chi:
                            compare_chi = chi_squared_result
                            key = (shifts, start, end)
                    run += 1
            shift = Shift(key)
            plaintext = shift.decrypt(ciphertext)

        return key, plaintext

class Vigenere:
    """
    ----------------------------------------------------
    Cipher name: Vigenere Cipher
    Key:         (str): a character or a keyword
    Type:        Polyalphabetic Substitution Cipher
    Description: if key is a single characters, uses autokey method
                    Otherwise, it uses a running key
                 In autokey: key = autokey + plaintext (except last char)
                 In running key: repeat the key
                 Substitutes only alpha characters (both upper and lower)
                 Preserves the case of characters
    ----------------------------------------------------
    """
    
    DEFAULT_KEY = 'k'
    
    def __init__(self,key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default value: 'k'
        Description:  Vigenere constructor
                      sets _key
                      if invalid key, set to default key
        ---------------------------------------------------
        """
        self._key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Vigenere key
        ---------------------------------------------------
        """
        # your code here
        return self._key
       
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (str): non-empty string
        Return:       success: True/False
        Description:  Sets Vigenere cipher key to given key
                      All non-alpha characters are removed from the key
                      key is converted to lower case
                      if invalid key --> set to default key
        ---------------------------------------------------
        """
        key = ''.join(c.lower() for c in key if c.isalpha())

        if not self.valid_key(key):
            self._key = self.DEFAULT_KEY
            return False

        self._key = key
        return True
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Vigenere object. Used for testing
                      output format:
                      Vigenere Cipher:
                      key = <key>
        ---------------------------------------------------
        """
        return f"Vigenere Cipher:\nkey = {self._key}"
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Vigenere key
                      A valid key is a string composing of at least one alpha char
        ---------------------------------------------------
        """
        return isinstance(key, str) and any(c.isalpha() for c in key)

    @staticmethod
    def get_square():
        """
        ----------------------------------------------------
        static method
        Parameters:   -
        Return:       vigenere_square (list of string)
        Description:  Constructs and returns vigenere square
                      The square contains a list of strings
                      element 1 = "abcde...xyz"
                      element 2 = "bcde...xyza" (1 shift to left)
        ---------------------------------------------------
        """
        vigenere_square = []
        alphabet = string.ascii_lowercase
        for i in range(len(alphabet)):
            row = alphabet[i:] + alphabet[:i]
            vigenere_square.append(row)
        return vigenere_square

    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Vigenere Cipher
                      May use an auto character or a running key
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert type(plaintext) == str, 'invalid plaintext'

        if len(self._key) == 1:
            return self._encrypt_auto(plaintext)
        else:
            return self._encrypt_run(plaintext)

    def _encrypt_auto(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Private helper function
                      Encryption using Vigenere Cipher Using an autokey
        ---------------------------------------------------
        """
        ciphertext = ''
        alpha_length = 26
        key = self.get_key()

        for index, char in enumerate(plaintext):
            if not char.isalpha():
                ciphertext += char
                continue

            char_lower = char.lower()
            plain_ord = ord(char_lower) - ord('a')
            key_ord = ord(key[index % len(key)].lower()) - ord('a')
            cipher_ord = (plain_ord + key_ord) % alpha_length
            cipher_ord += ord('a')

            if char.isupper():
                cipher_ord -= ord('a')
                cipher_ord += ord('A')

            ciphertext += chr(cipher_ord)

        return ciphertext

    def _encrypt_run(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Private helper function
                      Encryption using Vigenere Cipher Using a running key
        ---------------------------------------------------
        """
        ciphertext = ''
        alpha_length = 26
        key_length = len(self._key)
        key_index = 0

        for char in plaintext:
            if not char.isalpha():
                ciphertext += char
                continue

            char_lower = char.lower()
            plain_ord = ord(char_lower) - ord('a')
            key_ord = ord(self._key[key_index % key_length].lower()) - ord('a')
            cipher_ord = (plain_ord + key_ord) % alpha_length
            cipher_ord += ord('a')

            if char.isupper():
                cipher_ord -= ord('a')
                cipher_ord += ord('A')

            ciphertext += chr(cipher_ord)

            key_index = (key_index + 1) % key_length

        return ciphertext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Vigenere Cipher
                      May use an auto character or a running key
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid input'
        
        if len(self._key) == 1:
            return self._decryption_auto(ciphertext)
        else:
            return self._decryption_run(ciphertext)

    def _decryption_auto(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Private Helper method
                      Decryption using Vigenere Cipher Using autokey
        ---------------------------------------------------
        """
        plaintext = ''
        alpha_length = 26
        key = self.get_key()

        for index, char in enumerate(ciphertext):
            if not char.isalpha():
                plaintext += char
                continue

            char_lower = char.lower()
            cipher_ord = ord(char_lower) - ord('a')
            key_ord = ord(key[index % len(key)].lower()) - ord('a')
            plain_ord = (cipher_ord - key_ord) % alpha_length
            plain_ord += ord('a')

            if char.isupper():
                plain_ord -= ord('a')
                plain_ord += ord('A')

            plaintext += chr(plain_ord)

        return plaintext

    def _decryption_run(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Private Helper method
                      Decryption using Vigenere Cipher Using running key
        ---------------------------------------------------
        """
        plaintext = ''
        alpha_length = 26
        key_length = len(self._key)
        key_index = 0

        if key_length == 0:
            return plaintext

        for char in ciphertext:
            if not char.isalpha():
                plaintext += char
                continue

            char_lower = char.lower()
            cipher_ord = ord(char_lower) - ord('a')
            key_ord = ord(self._key[key_index % key_length].lower()) - ord('a')
            plain_ord = (cipher_ord - key_ord) % alpha_length
            plain_ord += ord('a')

            if char.isupper():
                plain_ord -= ord('a')
                plain_ord += ord('A')

            plaintext += chr(plain_ord)

            key_index += 1

        return plaintext

    @staticmethod
    def cryptanalyze_key_length(ciphertext):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   ciphertext (str)
        Return:       key_lenghts (list)
        Description:  Finds key length for Vigenere Cipher
                      Combines results of Friedman and Cipher Shifting
                      Produces a list of key lengths from the above two functions
                      Start with Friedman and removes duplicates
        ---------------------------------------------------
        """

        friedman_lengths = Cryptanalysis.friedman(ciphertext)
        shifting_lengths = Cryptanalysis.cipher_shifting(ciphertext)

        key_lengths = []
        for length in friedman_lengths + shifting_lengths:
            if length not in key_lengths:
                key_lengths.append(length)

        return key_lengths

    @staticmethod
    def cryptanalyze(ciphertext):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
        Return:       key,plaintext
        Description:  Cryptanalysis of Shift Cipher
                      Returns plaintext and key (shift,start_indx,end_indx)
                      Uses the key lengths produced by Vigenere.cryptanalyze_key_length
                      Finds out the key, then apply chi_squared
                      The key with the lowest chi_squared value is returned
        Asserts:      ciphertext is a non-empty string
        ---------------------------------------------------
        """
        base = ' ' + '\n' + utilities.get_chars('nonalpha')
        cleaned_ciphertext = utilities.clean_text(ciphertext, base)

        key_lengths = Vigenere.cryptanalyze_key_length(ciphertext)
        key = ''
        plaintext = ''

        minimumValue = None

        for key_length in key_lengths:
            blocks = utilities.text_to_blocks(cleaned_ciphertext, key_length, True)
            baskets = utilities.blocks_to_baskets(blocks)

            potential_key_word = ''.join(
                [chr(Shift.cryptanalyze(basket, [utilities.get_chars("lower"), -1, key_length])[0][0] + 97)
                 for basket in baskets])

            vigenereObject = Vigenere(potential_key_word)
            possible_plaintext = vigenereObject.decrypt(ciphertext)

            chi_val = Cryptanalysis.chi_squared(possible_plaintext)

            if minimumValue is None or chi_val < minimumValue:
                minimumValue = chi_val
                key = potential_key_word
                plaintext = possible_plaintext

        return key, plaintext